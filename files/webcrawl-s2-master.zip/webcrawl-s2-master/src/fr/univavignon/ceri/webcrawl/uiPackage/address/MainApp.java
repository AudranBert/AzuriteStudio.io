package fr.univavignon.ceri.webcrawl.uiPackage.address;



import java.io.IOException;

import fr.univavignon.ceri.webcrawl.uiPackage.address.model.LaunchSettings;
import fr.univavignon.ceri.webcrawl.uiPackage.address.model.Url;
import fr.univavignon.ceri.webcrawl.uiPackage.address.view.GraphController;
import fr.univavignon.ceri.webcrawl.uiPackage.address.view.LaunchController;
import fr.univavignon.ceri.webcrawl.uiPackage.address.view.SceneController;
import fr.univavignon.ceri.webcrawl.uiPackage.address.view.SettingsController;
import fr.univavignon.ceri.webcrawl.uiPackage.address.view.UrlOverviewController;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
//import projet.address.view.PersonOverviewController;
import javafx.collections.ObservableList; 


public class MainApp extends Application {

    private Stage primaryStage;
    private BorderPane rootLayout;
    
    //private ObservableList<Url> urlData = FXCollections.observableArrayList(); 
    private SceneController sceneController;
    
    private LaunchSettings settings = new LaunchSettings(); 
   

    
    public MainApp() {
    	//Exemple de donn�es
    	/*urlData.add(new Url("www.google.com"));
		urlData.add(new Url("www.amazon.com"));
		urlData.add(new Url("www.LDLC.com"));
		urlData.add(new Url("http://www.charlatans.info/")); */
		
		
	}
    
    /**
	 * Returns the data as an observable list of Persons. 
	 * @return
	 */
	/*public ObservableList<Url> getUrlData() {
		return urlData;
	}*/
    public LaunchSettings getSettings()
    {
    	return settings;
    }
	
	public SceneController getSceneController()
	{
		return sceneController; 
	}
    
    
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("WebCrawler");
        this.primaryStage.setResizable(false);

        initRootLayout();

        showUrlOverview();
    }
    
    /**
     * Initializes the root layout.
     */
    public void initRootLayout() {
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();
            
            // Show the scene containing the root layout.
            sceneController = loader.getController();
            sceneController.setMainApp(this);
            //System.out.println(this);
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    public void showUrlOverview() {
        try {
            // Load person overview.
        	
            FXMLLoader loader = new FXMLLoader();
                       
            loader.setLocation(MainApp.class.getResource("view/UrlOverview.fxml"));
          
            AnchorPane urlOverview = (AnchorPane) loader.load();       
            // Set person overview into the center of root layout.
            rootLayout.setCenter(urlOverview);
       
            UrlOverviewController controller = loader.getController(); 
            controller.setMainApp(this);
            //System.out.println(this); 
            
          
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void showSettingsOverview() {
        try {
            
            FXMLLoader loader = new FXMLLoader();
                       
            loader.setLocation(MainApp.class.getResource("view/SettingsOverview.fxml"));
          
            AnchorPane urlOverview = (AnchorPane) loader.load();       
            
            rootLayout.setCenter(urlOverview);
            
            SettingsController controller = loader.getController(); 
            controller.setMainApp(this);
                 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void showLaunchOverview() throws Exception {
        try {
            
            FXMLLoader loader = new FXMLLoader();
                       
            loader.setLocation(MainApp.class.getResource("view/LaunchOverview.fxml"));
          
            AnchorPane urlOverview = (AnchorPane) loader.load();       
           
            rootLayout.setCenter(urlOverview);
            
            LaunchController controller = loader.getController(); 
            controller.setMainApp(this);           
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void showGraphDialog() {
        try {
            
        	// Charge le fichier xml et creer une nouvelle scenne pour le popup du graphe
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/GraphDialog.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // creer la scene
            Stage dialogStage = new Stage();
            dialogStage.setResizable(false);
            dialogStage.setTitle("Graphique");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            GraphController controller = loader.getController();
            controller.setDialogStage(dialogStage);
          
            // Affiche la fenetre et attend que l'utilisateur la ferme
            dialogStage.showAndWait();

            //return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
            
        }
    }
    
	/**
	 * Returns the main stage.
	 * @return
	 */
	public Stage getPrimaryStage() {
		return primaryStage;
		 
	}

    public static void main(String[] args) {
        launch(args);
    }
}