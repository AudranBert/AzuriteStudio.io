package fr.univavignon.ceri.webcrawl;


import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Line;
import javafx.scene.paint.Color;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.input.MouseButton;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos; 
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.Axis;
import javafx.scene.shape.Rectangle;
import javafx.scene.image.WritableImage;
import javafx.scene.SnapshotParameters;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.time.LocalTime ;
import java.io.File;
import javafx.embed.swing.SwingFXUtils;
import java.lang.String;

public class Graphique {

    ObservableList<XYChart.Data> listePointsLiens = FXCollections.observableArrayList();
    ObservableList<XYChart.Data> listePointsNoeuds = FXCollections.observableArrayList();
    Axis axeX;
    Axis axeY;

	public void display() {
		Stage window = new Stage();
		window.setTitle("Graphique");
		
		window.initModality(Modality.APPLICATION_MODAL);

	    Pane root = new Pane();

	    // cr�ation d'une s�rie de liste de donn�es
	    ObservableList<XYChart.Series> seriesList = FXCollections.observableArrayList();

	    // cr�ation d'une liste de donn�es (vide) qui sera incr�ment�e avec le temps
	    seriesList.add(new XYChart.Series("Liens", listePointsLiens));

	    // cr�ation d'une liste de donn�es (vide) qui sera incr�ment�e avec le temps
	    seriesList.add(new XYChart.Series("Noeuds", listePointsNoeuds));
	    	    
	    axeX = new NumberAxis();
	    axeY = new NumberAxis();
	    axeX.setLabel("temps (en minute)");
	    axeY.setLabel("Valeur");
	    
	    LineChart chart = new LineChart(axeX, axeY, seriesList);
	    
	    root.getChildren().addAll(chart);

	    Scene scene = new Scene(root);
	    
	    scene.setOnMouseClicked(mouseEvent -> 
	    {
	    	if (mouseEvent.getButton() == MouseButton.SECONDARY) //clique droit
	    	{
	    		WritableImage image = scene.snapshot(null); //screen de la scene
	    		DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyy_MM_dd"); //format de date aaaa/mm/jj
                DateTimeFormatter moment = DateTimeFormatter.ofPattern("_HH_mm_ss"); //format de moment hh/mm/ss
	    		String path = new String("H:\\mes_docs\\images\\Projet_Prog\\" + date.format(LocalDate.now()) + moment.format(LocalTime.now()) + ".png"); //chemin pour sauvegarder le fichier
	    		File file = new File(path);  //fichier 
	    		try {
	    			ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file);
	    		} catch (IOException e) {
	    			e.printStackTrace();
	    		}
	    	}
		});
	
	    
	    window.setScene(scene);
	    window.show();		
		
	}
	
	public void AjouterLien(int temps, int valeur) {
    	this.listePointsLiens.add(new XYChart.Data(temps, valeur));
	}

	public void AjouterNoeud(int temps, int valeur) {
    	this.listePointsNoeuds.add(new XYChart.Data(temps, valeur));
	}

	
}
