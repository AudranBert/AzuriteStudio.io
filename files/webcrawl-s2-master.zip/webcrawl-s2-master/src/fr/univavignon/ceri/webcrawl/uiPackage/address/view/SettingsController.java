package fr.univavignon.ceri.webcrawl.uiPackage.address.view;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sun.glass.ui.Window;

import fr.univavignon.ceri.webcrawl.uiPackage.address.MainApp;
import fr.univavignon.ceri.webcrawl.uiPackage.address.model.LaunchSettings;
import fr.univavignon.ceri.webcrawl.uiPackage.address.model.Url;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Spinner;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.Node;

public class SettingsController {

    private LaunchSettings settings; 
	
    private MainApp mainApp;
    
    @FXML
    private ComboBox<String> comboBox;
    
    @FXML
    private Spinner<Integer> numberProcess; 
    
    @FXML
    private Spinner<Integer> hours; 
    
    @FXML
    private Spinner<Integer> minutes; 
    
    @FXML 
    private Spinner<Integer> radius; 
    
    @FXML
    private CheckBox robotTxt;
    
    @FXML
    private CheckBox siteMap; 
    
    @FXML
    private CheckBox inDomain; 
    
    /*@FXML
    private */ 
    
    public SettingsController() {
	
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
    	comboBox.getItems().clear();;
        comboBox.getItems().addAll("Page", "Domain");
        comboBox.getSelectionModel().select("Page");     
    	
    }
    
    public void setMainApp(MainApp mainApp) {
    	//System.out.println(mainApp);
        this.mainApp = mainApp;
        
        settings = mainApp.getSettings();
        
        SceneController sceneC = this.mainApp.getSceneController();
        
        Pattern p = Pattern.compile("(@)?(href=')?(HREF=')?(HREF=\")?(href=\")?(http://)?(https://)?[a-zA-Z_0-9\\-]+(\\.\\w[a-zA-Z_0-9\\-]+)+(/[#&\\n\\-=?\\+\\%/\\.\\w]+)?"); 
        
        if(settings.getUrlData().size() > 0)
        {
        	for (Url i : settings.getUrlData())
            {
            	
           	 //System.out.println("valeur: " + i.getUrl());
             Matcher m1 = p.matcher(i.getUrl()); 
           	
           	 boolean b = m1.matches();
           	 
           	 //System.out.println(b + " ");
           	 if(!b)
           		{
           		 
           		sceneC.buttonDisable("b3");
           		break; 
           		}
           	 	sceneC.buttonEnable("b3");
            	
            }
        	 	
        }
        else
        {
        	sceneC.buttonDisable("b3");      	
        }
        
        //radius.getValueFactory().setValue(settings.getRadius());
        numberProcess.getValueFactory().setValue(settings.getProcessNumber());
        //hours.getValueFactory().setValue(settings.getTimeH());
        //minutes.getValueFactory().setValue(settings.getTimeM());
        
        if(settings.getRadius() > 1)
    	{
    		radius.getValueFactory().setValue(settings.getRadius());
    		hours.setDisable(true);
    		minutes.setDisable(true);
    		//settings.setRadius(0);
    		settings.setTimeH(0);
    		settings.setTimeM(0);
    	}
    	else
    	{
    		radius.setDisable(true);
    	}
        
        if(settings.getTimeH() > 0)
    	{
        	hours.getValueFactory().setValue(settings.getTimeH());
    		radius.setDisable(true);
    		settings.setRadius(0);
    	}      
    	else
    	{
    		radius.setDisable(false);
    	}
        
        if(settings.getTimeM() > 0)
    	{
        	minutes.getValueFactory().setValue(settings.getTimeM());
    		radius.setDisable(true);
    		settings.setRadius(0);
    	}
    	else
    	{
    		radius.setDisable(false);
    	}
        
        if(settings.isRobotTxt() == true)
        {
        	robotTxt.setSelected(true);
        }
        else
        {
        	robotTxt.setSelected(false); 
        }
        
        if(settings.isSiteMap()== true)
        {
        	siteMap.setSelected(true);
        }
        else
        {
        	siteMap.setSelected(false); 
        }
        
        if(settings.isInDomain() == true)
        {
        	inDomain.setSelected(true);
        }
        else
        {
        	inDomain.setSelected(false); 
        }
        
        if(settings.getNodeType() == false)
        {
        	comboBox.setValue("Page");
        }
        else
        {
        	comboBox.setValue("Domain");
        }
        
        if(settings.getProcessNumber() > 0)
        {
        	numberProcess.getValueFactory().setValue(settings.getProcessNumber());
        } 
        
        //enableLaunch();
        
    }   
    
    

    @FXML
    public void nodeTypeComboBoxAction()
    {
    	//System.out.println(comboBox.getValue());
    	if(comboBox.getValue().equals("Page"))
    	{
    		settings.setNodeType(false);
    	}
    	else if(comboBox.getValue().equals("Domain"))
    	{
    		settings.setNodeType(true);
    	}
    	
    	//System.out.println("valeur de noeud:" + settings.getNodeType()); 
    	
    }
    
    @FXML
    public void processNumberSpinnerAction()
    {
    	settings.setProcessNumber(numberProcess.getValue());
    	//System.out.println("valeur:" + settings.getProcessNumber());
    	
    }
    
    @FXML
    public void radiusSpinnerAction()
    {
    	if(radius.getValue() > 1)
    	{
    	
    		settings.setRadius(radius.getValue());
    		hours.setDisable(true); 
    		settings.setTimeH(0);
    		settings.setTimeM(0);
    		minutes.setDisable(true);
    	}
    	else
    	{
    		hours.setDisable(false);
    		minutes.setDisable(false);
    	}
    	
    	//System.out.println("valeur:" + settings.getRadius());
    	
    }
    
    @FXML
    public void TimeHourSpinnerAction()
    {
    	if(hours.getValue() > 0 )
    	{
    		settings.setTimeH(hours.getValue());
    		radius.setDisable(true);
    		settings.setRadius(0);
    	}
    	else if(minutes.getValue() == 0 )
    	{
    		radius.setDisable(false);
    	}
    	//enableLaunch();
    	//System.out.println("valeur:" + settings.getTimeH());
    }
    
    @FXML
    public void TimeMinutesSpinnerAction()
    {
    	if(minutes.getValue() != null) 
    	{
    		if(minutes.getValue() > 0)
    		{
    			settings.setTimeM(minutes.getValue());
    			radius.setDisable(true);
    			settings.setRadius(0);
    		}
    		else if(hours.getValue() == 0)
    		{
    			radius.setDisable(false);
    	
	    	}
    	}
    	//enableLaunch();
	    	//System.out.println("valeur:" + settings.getTimeM());
    	
    }
    
    @FXML
    public void robotTxtCheckBoxAction()
    {
    	settings.setRobotTxt(robotTxt.isSelected());
    	//System.out.println("valeur:" + settings.isRobotTxt());
    	
    }
    
    @FXML
    public void siteMapCheckBoxAction()
    {
    	settings.setSiteMap(siteMap.isSelected());
    	//System.out.println("valeur:" + settings.isSiteMap());
    	
    }
    
    
    @FXML
    public void inDomainCheckBoxAction()
    {
    	settings.setInDomain(inDomain.isSelected());
    	//System.out.println("valeur:" + settings.isInDomain());
    	
    }
    

	
}