package fr.univavignon.ceri.webcrawl.ParserPackage;
import java.io.BufferedReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.*;
import java.util.regex.*;


public class LinkParser {

	private String htmlSite = null;
	private int hauteur;
	private String modeParsing;
	private boolean resterDansDomaine = false;
	private String titreURL = null;
	private URL site; //creation d'un objet URL, pointant sur une ressource du Web.
	List<LinkParser> linkParserList =  new ArrayList<LinkParser>();
	List<LinkParser> linkParserListPrevious = null;
	private HashMap<URL, RobotsTxt> robotsMap;
	private boolean robotBool;
	private boolean sitemapBool;

	public LinkParser(URL site, boolean b, String modeParsing, int hauteur, List<LinkParser>listePrecedente, HashMap<URL, RobotsTxt> robotsMapCopy, boolean robotBoolCopy, boolean sitemapBoolCopy) throws Exception
	{
		this.site = site;
		this.resterDansDomaine = b;
		this.modeParsing  = modeParsing;
		this.hauteur = hauteur;
		this.linkParserListPrevious = listePrecedente;
		this.robotsMap = robotsMapCopy;
		this.robotBool = robotBoolCopy;
		this.sitemapBool = sitemapBoolCopy;

		if(hauteur>=1)
		{
			this.htmlSite = htmlToString();
			if(htmlSite!=null)
				linkParserList = parseURLPage();
		}
		else
			linkParserList = null;
	}

	public List<LinkParser> getURLList()
	{
		return linkParserList;
	}

	public int getHauteur()
	{
		return hauteur;
	}

	public HashMap<URL, RobotsTxt> getRobotsMap()
	{
		return robotsMap;
	}
	
	public String getTitre()
	{
		return titreURL;
	}

	public URL getURL()
	{
		return site;
	}
	public String getModeParsing() {	
		return modeParsing;
	}
	
	public boolean getStayOnDomain() {	
		return resterDansDomaine;
	}
	
	public void printURLs(int hauteurMax)
	{
		String s= "";
		for (int i=0; i<hauteurMax-this.hauteur;i++)
			s += "\t";
		System.out.println(s+this.getURL());
		for (int i=0; i<hauteur;i++)
		{
			for(LinkParser LP : this.linkParserList)
			{
				LP.printURLs(hauteurMax);
			}
		}
	}

	public void printURLs()
	{
		printURLs(hauteur);
	}



	private boolean containUrl(List<LinkParser> list ,String lien)
	{
		if(lien.contains("#"))
			return true;
		if (list==null)
			return false;
		for(LinkParser LP : list)
			if(LP.getURL().toString().equals(lien))
				return true;
		return false;
	}

	
	private String htmlToString(){

		try {
			StringBuilder SB = new StringBuilder();
			URLConnection openConnection = site.openConnection();
			openConnection.addRequestProperty("User-Agent", "Mozilla");
			openConnection.setReadTimeout(5000);
			openConnection.setConnectTimeout(5000);
			BufferedReader BR = new BufferedReader(new InputStreamReader(openConnection.getInputStream(), "UTF-8")); //BufferedReader prend en arguement un flux de lecture, ici openStream, mthode propre  URL
			String text;
			while ((text = BR.readLine()) != null)
				SB.append(text);
			BR.close();
			return SB.toString();
		}
		catch(IOException e){ //exception de lecture pour openstream()
			System.err.println(e);
		}

		return null;
	}

	/*private void findTitre() //fonction de titre fonctionnelle, non implementé car demande trop de ressource
	{
	if(htmlSite!=null)
		{
		Matcher titreMatcher = titre.matcher(htmlSite);
		if(titreMatcher.find())
			this.titreURL=titreMatcher.group(1);

		}
	}
	*/

	private List<LinkParser> parseURLPage() throws Exception{
		
		Pattern pattern = Pattern.compile("<a\\s+(?:[^>]*?\\s+)?href=([\"'])(https?)(.*?)\\1"); //regex acceptant seulement les hyperliens commenant par http ou https
		Pattern pattern2 = Pattern.compile("<a\\s+(?:[^>]*?\\s+)?href=([\"'])(?!https?)(?!javascript:void(0))(.*?)\\1"); //regex acceptant seulement les hyperliens ne commenant pas par http ou https
		Pattern titre = Pattern.compile("(?i)<title>(.*?)</title>"); //regex pour scanner le titre d'une page web
		Matcher matcher = pattern.matcher(htmlSite);
		Matcher matcher2 = pattern2.matcher(htmlSite);
		Matcher titreMatcher = titre.matcher(htmlSite);
		
		//Robots
		RobotsTxt robot;
		if(this.robotBool)
		{
			boolean shouldParse = false;
			if(robotsMap.get(new URL (this.site.getProtocol() + "://" + this.site.getHost())) == null)
			{
				robotsMap.put(new URL("https://" + this.site.getHost()), new RobotsTxt(this.site, this.sitemapBool));
				shouldParse = true;
			}
			robot = robotsMap.get(new URL (this.site.getProtocol() + "://" + this.site.getHost()));
			if(this.sitemapBool && shouldParse)
			{
				for(URL sitemapToParse: robot.getSitemapToParse())
				{
					System.out.println(sitemapToParse);
					linkParserList.add(new LinkParser(sitemapToParse,this.resterDansDomaine, this.modeParsing, this.hauteur-1, this.linkParserList, this.robotsMap, this.robotBool, this.sitemapBool)); //ajout des liens du sitemap
				}
			}
		}
		else
		{
			robot = new RobotsTxt();
		}

		
		if (titreMatcher.matches())
		{
			if(titreMatcher.find());
			titreURL = titreMatcher.group(1);
		}

		if(modeParsing=="Page")
		{
			if(matcher2.find())
			{
				while(matcher2.find())
				{
					String lien;
					if(matcher2.group(2)!=null)
						lien = (site.getProtocol() + "://" + site.getHost() + (matcher2.group(2))); //le groupe 2 du matcher correspond  ce qu'il se trouve dans la balise href
					else
						lien = (site.getProtocol() + "://" + site.getHost());

					try
					{
						//System.out.println("test");
						if(!containUrl(linkParserListPrevious,lien) && !containUrl(linkParserList,lien))
						{
							if((!(this.robotBool)) || (this.robotBool && robot != null && robot.Access(lien)))
							{
								linkParserList.add(new LinkParser(new URL(lien),this.resterDansDomaine, this.modeParsing, this.hauteur-1, this.linkParserList, this.robotsMap, this.robotBool, this.sitemapBool)); //ajout des liens locaux concatns avec le domaine en question
							}
						}
					}

					catch(MalformedURLException e)
					{
						System.err.println(matcher2.group(0));
						System.err.println(lien);
					}
				}
			}
		}
		else if(modeParsing =="Domaine")
		{

			String lien = site.getProtocol() + "://" + site.getHost();
			try
			{
				if(!containUrl(linkParserListPrevious, lien) && !containUrl(linkParserList,lien))
				{
					if((!(this.robotBool)) || (this.robotBool && robot != null && robot.Access(lien)))
					{
						linkParserList.add(new LinkParser(new URL(lien),this.resterDansDomaine, this.modeParsing, this.hauteur-1, this.linkParserList, this.robotsMap, this.robotBool, this.sitemapBool)); //ajout des liens locaux concatns avec le domaine en question
					}
				}
			}
			catch (MalformedURLException e)
			{
				System.err.println(e);
			}
		}

		while(matcher.find())
		{
			String lien = (matcher.group(2) + matcher.group(3));

			try {

				if(modeParsing=="Page"){}
				else if(modeParsing=="Domaine") {
					URL lienU = new URL(lien);
					lien = (lienU.getProtocol() + "://" + lienU.getHost());
				}

				if(!resterDansDomaine && /*!lien.contains(titreURL) &&*/ !containUrl(linkParserListPrevious,lien) && !containUrl(linkParserList,lien))
				{
					if((!(this.robotBool)) || (this.robotBool && robot != null && robot.Access(lien)))
					{
						linkParserList.add(new LinkParser(new URL(lien),this.resterDansDomaine, this.modeParsing, this.hauteur-1, this.linkParserList, this.robotsMap, this.robotBool, this.sitemapBool)); //ajout des liens locaux concatns avec le domaine en question
					}
				}
			}
			catch(MalformedURLException e)
			{
				System.err.println(lien);
			}

		}


		/*
		for(LinkParser LP : URLListDoublon) // si l'URL est dj dans la liste alors on ne l'insre pas + verification ancre
		{
			String s = LP.getURL().toString();
			if (!LinkParserList.contains(LP) && !(s.contains("#"))) {
                LinkParserList.add(LP);
            }
		}
		*/
		return linkParserList;
	}


}
