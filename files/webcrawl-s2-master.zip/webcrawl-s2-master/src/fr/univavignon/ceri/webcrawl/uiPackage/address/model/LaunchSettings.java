package fr.univavignon.ceri.webcrawl.uiPackage.address.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class LaunchSettings {
	
	private ObservableList<Url> urlData = FXCollections.observableArrayList(); // = FXCollections.observableArrayList();  
	
	private boolean nodeType = false ;
	private int processNumber = 1; 
	private boolean robotTxt = false;
	private boolean siteMap = false; 
	
	private int radius = 1; 
	private int timeH = 0;
	private int timeM = 0; 
	
	private boolean inDomain = false;

	public boolean getNodeType() {
		return nodeType;
	}

	public void setNodeType(boolean nodeType) {
		this.nodeType = nodeType;
	}

	public int getProcessNumber() {
		return processNumber;
	}

	public void setProcessNumber(int processNumber) {
		this.processNumber = processNumber;
	}

	public boolean isRobotTxt() {
		return robotTxt;
	}

	public void setRobotTxt(boolean robotTxt) {
		this.robotTxt = robotTxt;
	}

	public boolean isSiteMap() {
		return siteMap;
	}

	public void setSiteMap(boolean siteMap) {
		this.siteMap = siteMap;
	}

	public int getTimeH() {
		return timeH;
	}

	public void setTimeH(int timeH) {
		this.timeH = timeH;
	}

	public int getTimeM() {
		return timeM;
	}

	public void setTimeM(int timeM) {
		this.timeM = timeM;
	}

	public boolean isInDomain() {
		return inDomain;
	}

	public void setInDomain(boolean inDomain) {
		this.inDomain = inDomain;
	}

	public ObservableList<Url> getUrlData() {
		return urlData;
	}

	public void setUrlData(ObservableList<Url> urlData) {
		this.urlData = urlData;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
	
	

}