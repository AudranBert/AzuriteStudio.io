package fr.univavignon.ceri.webcrawl.GraphPackage;
import java.io.File;
import java.io.IOException;
import java.util.*;
/*
https://www.softwaretestinghelp.com/java-graph-tutorial/
https://www.baeldung.com/java-graphs
https://fr.wikipedia.org/wiki/Th%C3%A9orie_des_graphes

https://docs.oracle.com/javase/7/docs/api/java/util/ArrayList.html

https://docs.yworks.com/yfiles/doc/developers-guide/graphml.html
 */

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import fr.univavignon.ceri.webcrawl.ParserPackage.ThreadLinkParser;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * @author audran
 * Graph class
 * boolean weighted
 * list of nodes
 */

public class Graph {
	private ArrayList<Node> listNode;
	private boolean weighted=true;  //true -> graph weighted
	public ArrayList<Node> getlistNode(){
		return listNode;
	}



	/**
	 * constructeur
	 * @param weighted
	 */
	public Graph(boolean weighted) {
		super();
		this.listNode=null;
		this.weighted=weighted;
	}
	/**
	 * constructeur
	 */
	public Graph() {
		super();
		this.listNode=null;
	}
	
	/**
	 * getweighted
	 * @return this.weighted
	 */
	public boolean getweighted() {
		return this.weighted;
	}
	
	
	/**
	 * toString
	 * return String
	 */
	@Override
	public String toString() {
		String text="";
		for (int i=0;i<listNode.size();i++) {
			text=text+"\n"+listNode.get(i).toString();
		}
		String all="Graph ["+listNode.size()+"=" + text + "\n]";
		return all;
	}
	

	
	/**
	 * addnode
	 * @param node
	 * @return boolean
	 */
	public boolean addNode(Node node) {  		//noeud deja cree
		if (node==null) {
			return false;
		}
		if (listNode!=null){
			return(listNode.add(node));
		}
		this.listNode=new ArrayList<Node>();
		return(listNode.add(node));
	}
	
	
	/**
	 * 
	 * 
	 */
	public boolean addNode(ThreadLinkParser nodeParser) {
		if (listNode==null) {
			listNode=new ArrayList<Node>();
		}
		if (weighted==true) {		//graphe de domaine
			if (nodeParser.getListLinkParser()!=null){
				for (int j=0;j<nodeParser.getListLinkParser().size();j++) {
					int pos=-1;
					for (int i=0; i<listNode.size();i++) {		//cherche si un noeud existe deja
						//System.out.println(listNode.get(i).getUrl()+"  VS  "+nodeParser.getListLinkParser().get(j).getURL().toString());
						if (listNode.get(i).getUrl()==nodeParser.getListLinkParser().get(j).getURL().toString()) {
							//System.out.println(nodeParser.getListLinkParser().get(j).getURL().toString());
							pos=i;
							break;
						}
					}
					if (pos!=-1) {				//si le node existe deja, l'actualiser
						
						listNode.get(pos).addEdge(nodeParser.getListLinkParser(), weighted);	
					}
					else {						//sinon le crer
						//System.out.println("Creer");
						Node node=new Node(nodeParser.getListLinkParser().get(j).getURL().toString(),nodeParser.getListLinkParser().get(j).getURL().toString());
						//node.addEdge(nodeParser.getListLinkParser(),weighted); 
						listNode.add(node);				
					}
				}
				Node node=new Node(nodeParser.getLink().toString(),nodeParser.getLink().toString());
				//System.out.println(node.getName());
				node.addEdge(nodeParser.getListLinkParser(),weighted); 
				listNode.add(node);
			}
		}
		else {				//si graphe pas de domaine
			//System.out.println(nodeParser.getList().size());
			if (nodeParser.getListLinkParser()!=null){
				for (int j=0;j<nodeParser.getListLinkParser().size();j++) {
					int pos=-1;
					for (int i=0; i<listNode.size();i++) {		
						//System.out.println(listNode.get(i).getUrl()+"  VS  "+nodeParser.getListLinkParser().get(j).getURL().toString());
						if (listNode.get(i).getUrl()==nodeParser.getListLinkParser().get(j).getURL().toString()) {
							pos=i;
							//System.out.println("Trouv");
							break;
						}
					}
					if (pos==-1) {				
						//System.out.println(nodeParser.getListLinkParser().get(j).getTitre());
						//Node node= new Node(nodeParser.getListLinkParser().get(j).getTitre(),nodeParser.getListLinkParser().get(j).getURL().toString());
						Node node= new Node(nodeParser.getListLinkParser().get(j).getURL().toString(),nodeParser.getListLinkParser().get(j).getURL().toString());
						//System.out.println(node.getName());
						listNode.add(node);
						
					}
				}	
			}
			//Node node=new Node(nodeParser.getTitle(),nodeParser.getLink().toString());
			Node node=new Node(nodeParser.getLink().toString(),nodeParser.getLink().toString());
			//System.out.println(node.getName());
			node.addEdge(nodeParser.getListLinkParser(),weighted); 
			listNode.add(node);
		}
		return true;
	}	
	
	
	/**
	 * addnode
	 * @param name
	 * @param url
	 * @return boolean
	 */
	public boolean addNode(String name, String url) {  //noeud pas cree
		if (name=="") {
			return false;
		}
		else if (url=="") {
			return false;
		}
		Node node = new Node(name,url);
		if (listNode!=null){
			return(listNode.add(node));
		}
		this.listNode=new ArrayList<Node>();
		return(listNode.add(node));
	}
		
	
	/**
	 * getfirstnode
	 * @deprecated
	 * @return Node
	 */
	public Node getFirstNode() {
		Node ret=listNode.get(0);
		if (ret!=null) {
			return ret;
		}
		return null;
	}

	/**
	 * searchnode
	 * @param name
	 * @return Node
	 */
	public Node searchNode(String name) {				//cherche un noeud
		for (int i=0;i<listNode.size();i++) {
			if (listNode.get(i).getName()==name) {
				return listNode.get(i);
			}
		}
		return null;
	}
	
	/**
	 * addedge
	 * @param src
	 * @param weight
	 * @param dest
	 * @return boolean
	 * @throws EdgeException
	 */
	public boolean addEdge(String src,int weight,String dest) throws EdgeException{	//ajout lien pas cree a un noeud dans le graphe
		Node n1=null;
		Edge e1=null;
		n1=this.searchNode(src);
		if (n1==null) {
			return false;
		}
		if (this.searchNode(dest)==null) {
			return false;
		}
		if (weight<=0) {
			return false;
		}
		if (this.weighted==false){
			weight=1;
		}
		e1=n1.searchEdge(src, dest);
		if ((e1!=null) && (this.weighted==true)){
			return e1.setweight(weight+e1.getweight());
		}
		else if (e1!=null) {
			//throw new LienException(l1,"deja existant");
			return false;
		}
		else {
			boolean res=n1.addEdge(src,weight,dest,-1);
			if (res==false) {
				return false;
			}
			return true;
		}
	}
	/**
	 * addedge
	 * @param src
	 * @param dest
	 * @return boolean
	 * @throws EdgeException
	 */
	public boolean addEdge(String src,String dest) throws EdgeException {		//ajout lien pas cree a un noeud du graphe (non weighted)
		return addEdge(src,1,dest);
	}
	

	
	
	

/*
* readGraphml
* @param filename
* @return boolean (success or not)
* read a graphML file and create a graph with it
 */

	public boolean readGraphml(String filename){
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		try{
			dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(new File(filename));
			doc.getDocumentElement().normalize();


			//root
			System.out.println("Root Element :" + doc.getDocumentElement().getNodeName());
			System.out.println("------");
			/*if (doc.hasChildNodes())
			{
				System.out.println(doc.getChildNodes());
			}*/

			//graph
			NodeList tmpG = doc.getElementsByTagName("graph");
			Element g= (Element) tmpG.item(0);
			String directed=g.getAttribute("edgedefault");
			System.out.println(directed);

			if (this.listNode==null){
				listNode=new ArrayList<>();
			}

			// nodes
			NodeList nodeList = doc.getElementsByTagName("node");
			for (int temp = 0; temp < nodeList.getLength(); temp++) {
				org.w3c.dom.Node nodeML = nodeList.item(temp);
				Element element = (Element) nodeML;
				// get id
				String idString = element.getAttribute("id");
				//get url
				org.w3c.dom.Node urlNode = element.getElementsByTagName("data").item(0);
				String furl="";
				if(urlNode!=null){
					furl = urlNode.getTextContent();
				}

				int id= Integer.parseInt(idString.substring(1));
				//add
				Node n=new Node(id,idString,furl);
				listNode.add(n);
			}

			//edges
			NodeList edgeList = doc.getElementsByTagName("edge");
			for (int temp = 0; temp < edgeList.getLength(); temp++) {
				org.w3c.dom.Node nodeML = edgeList.item(temp);
				Element element = (Element) nodeML;
				// get src
				String src = element.getAttribute("source");
				//get target
				String target = element.getAttribute("target");
				//to int id
				int srcIndex= Integer.parseInt(src.substring(1));
				int targetIndex= Integer.parseInt(target.substring(1));
				//System.out.println(srcIndex+" -> "+targetIndex);
				//get weight
				org.w3c.dom.Node weightNode = element.getElementsByTagName("data").item(0);
				String weightNodeTextContent = weightNode.getTextContent();
				int weight= Integer.parseInt(weightNodeTextContent);

				//System.out.println(targetIndex);
				boolean succeed=listNode.get(srcIndex).addEdge(listNode.get(srcIndex).getUrl(),weight,listNode.get(targetIndex).getUrl(),targetIndex);
			}
			/*for (int i=0;i<listNode.size();i++){
				System.out.println(listNode.get(i).toString());
			}*/
			return true;
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * addnodetodom
	 * @param doc
	 * @param graph
	 */
	public void addNodeToDOM(Document doc,Element graph) {
		if (listNode!=null) {
			for (int i=0;i<listNode.size();i++) {
				// l'�l�ment graph
				Element node = doc.createElement("node");
				graph.appendChild(node);

				// attributs de l'�l�ment graph
				Attr attr = doc.createAttribute("id");
				attr.setValue(listNode.get(i).getName());
				node.setAttributeNode(attr);

				Element nom = doc.createElement("data");
				node.appendChild(nom);
				attr = doc.createAttribute("key");
				attr.setValue("n0");
				nom.appendChild(doc.createTextNode(listNode.get(i).getName()));
				nom.setAttributeNode(attr);

				Element url = doc.createElement("data");
				node.appendChild(url);
				attr = doc.createAttribute("key");
				attr.setValue("n1");
				url.appendChild(doc.createTextNode(listNode.get(i).getUrl()));
				url.setAttributeNode(attr);

			}
			for (int i=0;i<listNode.size();i++) {
				listNode.get(i).addEdgeToDOM(this.weighted, doc, graph, i);
			}
		}
	}


	/**
	 * exporttographml
	 * export using dom
	 */
	public void exportToGraphml() {
		 
	      try {
	 
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder docBuilder = dbFactory.newDocumentBuilder();
	 
	     // �l�ment de racine --> Graphml
         Document doc = docBuilder.newDocument();
         
         Element racine = doc.createElement("graphml");
         doc.appendChild(racine);
         //attributs de l'�l�ment racine
         Attr attrRac = doc.createAttribute("xmlns");
         attrRac.setValue("http://graphml.graphdrawing.org/xmlns");
         racine.setAttributeNode(attrRac);
         
         Attr attrR1 = doc.createAttribute("xmlns:xsi");
         attrR1.setValue("http://www.w3.org/2001/XMLSchema-instance");
         racine.setAttributeNode(attrR1);
         
         Attr attrR2 = doc.createAttribute("xsi:schemaLocation");
         attrR2.setValue("http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd");
         racine.setAttributeNode(attrR2);
	 
         Element k1 = doc.createElement("key");
         racine.appendChild(k1);
         Attr attr = doc.createAttribute("id");
         attr.setValue("n0");
         k1.setAttributeNode(attr);
         attr = doc.createAttribute("for");
         attr.setValue("node");
         k1.setAttributeNode(attr);
         attr = doc.createAttribute("attr.name");
         attr.setValue("name");
         k1.setAttributeNode(attr);
         attr = doc.createAttribute("attr.type");
         attr.setValue("string");
         k1.setAttributeNode(attr);
         
         Element k2 = doc.createElement("key");
         racine.appendChild(k2);
         Attr attr2 = doc.createAttribute("id");
         attr2.setValue("n1");
         k2.setAttributeNode(attr2);
         attr2 = doc.createAttribute("for");
         attr2.setValue("node");
         k2.setAttributeNode(attr2);
         attr2 = doc.createAttribute("attr.name");
         attr2.setValue("url");
         k2.setAttributeNode(attr2);
         attr2 = doc.createAttribute("attr.type");
         attr2.setValue("string");
         k2.setAttributeNode(attr2);
         
         Element k3 = doc.createElement("key");
         racine.appendChild(k3);
         Attr attr3 = doc.createAttribute("id");
         attr3.setValue("e0");
         k3.setAttributeNode(attr3);
         attr3 = doc.createAttribute("for");
         attr3.setValue("edge");
         k3.setAttributeNode(attr3);
         attr3 = doc.createAttribute("attr.name");
         attr3.setValue("weight");
         k3.setAttributeNode(attr3);
         attr3 = doc.createAttribute("attr.type");
         attr3.setValue("int");
         k3.setAttributeNode(attr3);
         
      // l'�l�ment graph
         Element graph = doc.createElement("graph");
         racine.appendChild(graph);
  
     // attributs de l'�l�ment graph
         Attr attr4 = doc.createAttribute("id");
         attr4.setValue("G1");
         graph.setAttributeNode(attr4);
         
         Attr attr1 = doc.createAttribute("edgedefault");
         attr1.setValue("Directed");
         graph.setAttributeNode(attr1);
 			this.addNodeToDOM(doc, graph);
	        // write the content into xml file
	        TransformerFactory transformerFactory = TransformerFactory.newInstance();
	        Transformer transformer = transformerFactory.newTransformer();
	        DOMSource source = new DOMSource(doc);
	        StreamResult resultat = new StreamResult(new File("data.graphml"));
	 
	        transformer.transform(source, resultat);
	 
	        System.out.println("Fichier sauvegarde avec succes!");
	 
	     } catch (ParserConfigurationException pce) {
	         pce.printStackTrace();
	     } catch (TransformerException tfe) {
	         tfe.printStackTrace();
	     }
	  }

	
}
