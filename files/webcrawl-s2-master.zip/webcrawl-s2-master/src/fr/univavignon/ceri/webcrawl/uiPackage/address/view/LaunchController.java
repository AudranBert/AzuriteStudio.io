package fr.univavignon.ceri.webcrawl.uiPackage.address.view;






import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;

import com.sun.glass.ui.Window;

import fr.univavignon.ceri.webcrawl.ParserPackage.ThreadLinkParserManager;
import fr.univavignon.ceri.webcrawl.uiPackage.address.MainApp;
import fr.univavignon.ceri.webcrawl.uiPackage.address.model.LaunchSettings;
import fr.univavignon.ceri.webcrawl.uiPackage.address.model.Url;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Spinner;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Node;

public class LaunchController {

    private LaunchSettings settings; 
	
    private MainApp mainApp;
    
    @FXML
    private Label threadNumber;
    
    @FXML
    private Label urlNumber;
    
    @FXML 
    private Label nodeNumber;
    
    @FXML 
    private Label linkNumber;
    
    @FXML
    private Label timeCurrent;
    
    @FXML
    private Label timeLeft; 
    
    @FXML 
    private ProgressBar progressBar;
    
    private boolean stopThread; 
    
    int prog = 0;
    
   private ThreadLinkParserManager parser;
    
    public LaunchController () {
    	
    	
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
    	 //threadNumber.setText("oui");   
    	
    }
    
    public void setMainApp(MainApp mainApp) throws Exception {
    	System.out.println(mainApp);
    	System.out.println("lancement du programme"); 
        this.mainApp = mainApp;
        this.settings = mainApp.getSettings(); 
        
        
        int totalTime = settings.getTimeH() * 360 + settings.getTimeM() * 60; 
        ArrayList<URL> listUrl = new ArrayList<URL>(); 
        
        threadNumber.setText(Integer.toString(settings.getProcessNumber()));
        
        
        long depart = System.currentTimeMillis();
        
        //parser.crawlerExec(listUrl, 10, 1, 20, false, false);
        
        for (Url i : settings.getUrlData())
        {
        	listUrl.add(new URL(i.getUrl()));
        	
        }
        System.out.println("minutes: "+  settings.getTimeM());        
       parser = new ThreadLinkParserManager();
       Thread taskThread = new Thread(new Runnable() {
            @Override
            public void run() {		
            	try {
            		//crawlerExec(ArrayList<URL> listSrc,int nbThreadSimultinus, int hauteurMax, int timeMax , boolean domainGraph, boolean stayOnDomain)
					parser.crawlerExec(listUrl, settings.getProcessNumber(), settings.getRadius(), totalTime, settings.getNodeType(), settings.isInDomain(), settings.isRobotTxt(), settings.isSiteMap());
					Thread.sleep(1000);
					stopThread = true; //une fois que le parser est termin�, on arrete l'actualisation des donn�es.
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                Platform.runLater(new Runnable() {
                  @Override
                  public void run() {
                      
                  }
                }); 
              
            }
          }); 
       
       
        taskThread.start(); 
        
        Thread thread = new Thread(new Runnable() {    //declaration d'un nouveau thread

			@Override
		    public void run() { 
				Runnable updater = new Runnable() { //L'update � faire en boucle

					@Override
		            public void run() {
						nodeNumber.setText(Integer.toString(parser.getCtURLParsed()));
						linkNumber.setText(Integer.toString(parser.getCtURLFound()));
						
						long tempsActuel = System.currentTimeMillis();
						long difference = tempsActuel - depart;
						long heureEcoule = difference/(1000*60*60); //r�cup�re le nombre d'heures �coul�es
		                long minuteEcoule = (difference/(1000*60))%60; //r�cup�re le nombre de minutes �coul�es modulo 60
		               
		                timeCurrent.setText(Long.toString(heureEcoule ) + "h " + Long.toString(minuteEcoule) + "m " + (int)difference/1000 + "s");
		                //System.out.println("temps total: " + settings.getTimeH() * 3600 + settings.getTimeM() * 60);
		                if(totalTime > 0)
		                {
		                	long time = totalTime - 1; 
		                	timeLeft.setText(Long.toString(time) + "s");
		                	System.out.println("progr�s: " + tempsActuel * 100/ totalTime);
		                	//progressBar.setProgress(tempsActuel * 100 / );
		                }
		                else
		                {
		                	if(parser.getCtURLFound() > prog)
		                	{
		                		prog++; 
		                		double v = prog * 100 / 22;
		                		System.out.println(v);
		                		//System.out.println();
		                		v = v/100;
		                		progressBar.setProgress(v);
		                	}
		                }
	
					}
		        };	               
		        while (true) { //boucle pour incr�menter les valeurs (cr�er des valeurs bidons)
		        	try {
		        		Thread.sleep(1000); //attendre pour ne pas faire trop d'update/incr�mentations, ce ne sont que des valeurs bidons !
		        		
		             } catch (InterruptedException ex) {
		                System.out.println("Timer error");
		             }
		        	
	        		if (stopThread)
	        		{
	        			Thread.currentThread().interrupt();
	        			return;
	        		}
		                   
		              Platform.runLater(updater);//update les valeurs sur la GUI
		            }
		       	        
		    }
		});
		
		thread.setDaemon(true);
		thread.start();
        
        SceneController sceneC = this.mainApp.getSceneController(); 
        if(settings.getUrlData().size() > 0)
        {
        	sceneC.buttonEnable("b3");
        	
        }
        else
        {
        	sceneC.buttonDisable("b3");
        } 
       
    }
    
    @FXML
    public void OpenGraphWindow()
    {
    	mainApp.showGraphDialog();
    }

    

        
    
    
    
    
    
    
    
	
}
