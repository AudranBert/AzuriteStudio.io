package fr.univavignon.ceri.webcrawl.ParserPackage;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ThreadLinkParser implements Runnable {

		private int hauteur;
		private String modeParsing;
		private boolean resterDansDomaine;
		private URL link;								//url que le thread doit parser
		private String title;
		private List<LinkParser> listLinkParser = new ArrayList<LinkParser>();  //permet de stocker le resultat du thread
		private List<URL> listURL = new ArrayList<>();
		private HashMap<URL, RobotsTxt> robotsMap;
		private boolean robotBool;
		private boolean sitemapBool;

		public ThreadLinkParser(URL target, int hauteur, boolean resterDansDomaine, boolean modeParsing, HashMap<URL, RobotsTxt> map, boolean robotBoolCopy, boolean sitemapBoolCopy) {
			this.link=target;
			this.title=link.toString();
			this.hauteur = hauteur;
			this.resterDansDomaine = resterDansDomaine;
			this.robotsMap = map;
			this.robotBool = robotBoolCopy;
			this.sitemapBool = sitemapBoolCopy;
			if(modeParsing)
				this.modeParsing="Domaine";
			else
				this.modeParsing="Page";
		}
		
		public ThreadLinkParser(LinkParser linkParser) {
			this.link=linkParser.getURL();
			this.hauteur = linkParser.getHauteur();
			this.resterDansDomaine = linkParser.getStayOnDomain();
			this.modeParsing=linkParser.getModeParsing();
			robotsMap=linkParser.getRobotsMap();
		}
		
		public URL getLink() {
			return link;
		}
		
		public String getTitle() {
			return title;
		}
		
		public void setLink(URL link) {
			this.link = link;
		}
		
		public List<LinkParser> getListLinkParser() {
			return this.listLinkParser;
		}

		public List<URL> getList() {
			return this.listURL;
		}
		
		public HashMap<URL, RobotsTxt> getRobotsMap()
		{
			return robotsMap;
		}
		
		public void run() {
			LinkParser parser;
			try {
				parser = new LinkParser(this.link, this.resterDansDomaine, this.modeParsing, this.hauteur, null, this.robotsMap, this.robotBool, this.sitemapBool);
				this.title=parser.getTitre();
				listLinkParser = parser.getURLList();
				if (listLinkParser!=null) {
					for (int i=0;i<listLinkParser.size();i++) {
						listURL.add(listLinkParser.get(i).getURL());
					}
				}
				//parser.printURLs();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
}

