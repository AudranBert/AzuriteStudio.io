/*package fr.univavignon.ceri.webcrawl;


import javafx.application.Application;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Line;
import javafx.scene.paint.Color;
import javafx.scene.control.ProgressBar;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos; 
import javafx.application.Platform;
*/
//public class lancement extends Application {
	
/*	Button button;
	int nbrThread = 3; //nombre de thread utilis�s, r�cup�rer valeur de "configuration" ?
	int nbrUrl = 0; //nombre d'url compt�es
	int nbrNoeuds = 2; //nombre de noeuds cr��s
	int nbrLiens = 0; //nombre de liens travers�s
	long heureEcoule = 0; //nombre d'heures �coul�es
	long minuteEcoule = 0; //nombre de minutes �coul�es
	long tempsTotalEstime = 3; //temps estim� pour le dur�e du programme (en phase de test, cette variable sert de fin pour la dur�e du programme)
	long heureRestant = tempsTotalEstime/60; //nombre d'heures restantes avant la fin du programme
	long minuteRestant = tempsTotalEstime%60; //nombre de minutes restantes avant la fin du programme
    long depart = System.currentTimeMillis(); //moment de d�part du programme
	long tempsActuel; //sera r�utilis�e pour avoir le temps actuel
	long difference; //difference entre temps actuel et temps de d�part
	long tempsThreadGraphique = 0; //sert de rep�re pour savoir quand 1 minute est �coul�e pour mettre � jour le graphique
	boolean stopThread = false; //le Thread arr�te de s'ex�cuter quand stopThread passe � true

	public static void main(String[] args) {
		launch(args);
	}
*/	
//	@Override
//	public void start(Stage primaryStage) {
				
/*		primaryStage.setTitle("lancement");

		
		GridPane grid = new GridPane(); //grid avec la plus part de la sc�ne
		grid.setPadding(new Insets(10, 10, 10, 10));
		grid.setVgap(8);
		grid.setHgap(10);

		Label labThread = new Label();
		labThread.setText("Nombre de thread : " + nbrThread);
		GridPane.setConstraints(labThread, 0, 0); //affichage de nbr_Thread
		
		Label labUrl = new Label();
		labUrl.setText("Nombre d'URL compt�es : " + nbrUrl);
		GridPane.setConstraints(labUrl, 0, 1); //affichage de nbn_url

		Label labGraphe = new Label(); 
		labGraphe.setText("Graphe");
		GridPane.setConstraints(labGraphe, 1, 2); //affichage du mot "Graphe"

		Label labNoeuds = new Label(); 
		labNoeuds.setText("Nombre de noeuds : " + nbrNoeuds);
		GridPane.setConstraints(labNoeuds, 2, 3); //affichage du nombre de Noeuds cr��s"

		Label labLiens = new Label(); 
		labLiens.setText("Nombre de liens : " + nbrLiens);
		GridPane.setConstraints(labLiens, 2, 4); //affichage du nombre de liens parcourus
		
*/
		
/*		//boutton pour acc�der au graphique
		Button graphiquebtn = new Button();
		graphiquebtn.setText("graphique");
		GridPane.setConstraints(graphiquebtn, 2, 5);
		Graphique graphique = new Graphique();
		graphiquebtn.setOnAction(e -> graphique.display());
*/		
		//premier cadre
/*		Line grapheTop = new Line(0,0,150,0); //Ligne du haut
		grapheTop.setStrokeWidth(2);
		grapheTop.setStroke(Color.BLACK);
		GridPane.setConstraints(grapheTop, 2, 2);
		Line grapheLeft = new Line(0,0,0,30); //Ligne de gauche1
		grapheLeft.setStrokeWidth(2);
		grapheLeft.setStroke(Color.BLACK);
		GridPane.setConstraints(grapheLeft, 1, 3);
		Line grapheLeft2 = new Line(0,0,0,30); //Ligne de gauche2
		grapheLeft2.setStrokeWidth(2);
		grapheLeft2.setStroke(Color.BLACK);
		GridPane.setConstraints(grapheLeft2, 1, 4);
		Line grapheLeft3 = new Line(0,0,0,30); //Ligne de gauche3
		grapheLeft3.setStrokeWidth(2);
		grapheLeft3.setStroke(Color.BLACK);
		GridPane.setConstraints(grapheLeft3, 1, 5);
		Line grapheBot = new Line(0,0,150,0); //Ligne du bas
		grapheBot.setStrokeWidth(2);
		grapheBot.setStroke(Color.BLACK);
		GridPane.setConstraints(grapheBot, 2, 6);
		Line grapheRight = new Line(0,0,0,30); //Ligne de droite
		grapheRight.setStrokeWidth(2);
		grapheRight.setStroke(Color.BLACK);
		GridPane.setConstraints(grapheRight, 4, 3); 
		Line grapheRight2 = new Line(0,0,0,30); //Ligne de droite2
		grapheRight2.setStrokeWidth(2);
		grapheRight2.setStroke(Color.BLACK);
		GridPane.setConstraints(grapheRight2, 4, 4); 
		Line grapheRight3 = new Line(0,0,0,30); //Ligne de droite3
		grapheRight3.setStrokeWidth(2);
		grapheRight3.setStroke(Color.BLACK);
		GridPane.setConstraints(grapheRight3, 4, 5); 
		
		Label labTemps = new Label();
		labTemps.setText("Temps");
		GridPane.setConstraints(labTemps, 1, 7);  //affichage du mot "Temps"
		
		Label labEcoule = new Label(); //affichage du temps �coul�
		labEcoule.setText("Temps �coul� : " + heureEcoule + "h0" + minuteEcoule); //initialisation du temps �coul�
		GridPane.setConstraints(labEcoule, 2, 8); 			

		Label labRestant = new Label(); //affichage du temps restant
		labRestant.setText("Temps restant : " + heureRestant + "h0" + minuteRestant);
		GridPane.setConstraints(labRestant, 2, 9);

		
		//deuxi�me cadre
		Line tempsTop = new Line(0,0,150,0); //Ligne du haut
		tempsTop.setStrokeWidth(2);
		tempsTop.setStroke(Color.BLACK);
		GridPane.setConstraints(tempsTop, 2, 7);
		Line tempsLeft = new Line(0,0,0,30); //Ligne de gauche1
		tempsLeft.setStrokeWidth(2);
		tempsLeft.setStroke(Color.BLACK);
		GridPane.setConstraints(tempsLeft, 1, 8);
		Line tempsLeft2 = new Line(0,0,0,30); //Ligne de gauche2
		tempsLeft2.setStrokeWidth(2);
		tempsLeft2.setStroke(Color.BLACK);
		GridPane.setConstraints(tempsLeft2, 1, 9);
		Line tempsBot = new Line(0,0,150,0); //Ligne du bas
		tempsBot.setStrokeWidth(2);
		tempsBot.setStroke(Color.BLACK);
		GridPane.setConstraints(tempsBot, 2, 10);
		Line tempsRight = new Line(0,0,0,30); //Ligne de droite
		tempsRight.setStrokeWidth(2);
		tempsRight.setStroke(Color.BLACK);
		GridPane.setConstraints(tempsRight, 4, 8); 
		Line tempsRight2 = new Line(0,0,0,30); //Ligne de droite2
		tempsRight2.setStrokeWidth(2);
		tempsRight2.setStroke(Color.BLACK);
		GridPane.setConstraints(tempsRight2, 4, 9); 

		
		HBox progressBox = new HBox(); //gestion de la progress bar
		ProgressBar progress = new ProgressBar(0);
		progress.setMinWidth(400);
		progressBox.getChildren().addAll(progress);
	    progressBox.setAlignment(Pos.CENTER);
		
	    
		Button cible3 = new Button("Cible");  //gestion des boutons de navigation
		Button configuration3 = new Button("Configuration"); 
		Button lancement3 = new Button("STOP");		
		cible3.setDisable(true);
		configuration3.setDisable(true);
*/		
		
/*		lancement3.setOnAction(e -> //lancement ou arr�t du Crawler
		{
			if(lancement3.getText() == "STOP") //arreter du Crawler
			{
                tempsActuel = System.currentTimeMillis();
                difference = tempsActuel - depart;
                graphique.AjouterLien((int)(difference) / 60000, nbrLiens);
            	graphique.AjouterNoeud((int)(difference) / 60000, nbrNoeuds);
				stopThread = true;
				lancement3.setText("Lancement"); 
				cible3.setDisable(false);
				configuration3.setDisable(false);
				//rajouter exportation du graphe au format graphml
			}
			else //relancer le crawler
			{
				//ligne pour relancer le crawler
				lancement3.setText("STOP"); 
				cible3.setDisable(true);
				configuration3.setDisable(true); 
			}
		});
		
//		cible.setOnAction(e -> window.setScene(sceneCible));
//		configuration.setOnAction(e -> window.setScene(sceneConfig));
*/
		//box pour la navigation
/*	    HBox box3 = new HBox();
		box3.setPadding(new Insets(15, 12, 15, 12));
		box3.setSpacing(10); 
	    box3.getChildren().addAll(cible3, configuration3, lancement3);
	    box3.setAlignment(Pos.BOTTOM_CENTER);
*/		
/*	    //principale partie de la page
		grid.getChildren().addAll(labThread, labUrl, labGraphe, labNoeuds, labLiens, graphiquebtn, labTemps, labEcoule, labRestant, grapheTop, grapheLeft, grapheLeft2, grapheBot, grapheRight, grapheRight2, grapheRight3, grapheLeft3, tempsTop, tempsLeft, tempsLeft2, tempsBot, tempsRight, tempsRight2);
*/		
/*		//progress bar, au "centre" de l'�cran
		BorderPane border = new BorderPane();
		border.setBottom(box3);
		border.setCenter(progressBox);
		border.setTop(grid);
*/	    
//		Scene scene = new Scene(border, 450, 450);
	
		
/*		Thread thread = new Thread(new Runnable() {    //declaration d'un nouveau thread

			@Override
		    public void run() { 
				Runnable updater = new Runnable() { //L'update � faire en boucle

					@Override
		            public void run() {
		                tempsActuel = System.currentTimeMillis();
		                difference = tempsActuel - depart;
		                labUrl.setText("Nombre d'URL compt�es : "+ nbrUrl);
			               labNoeuds.setText("Nombre de Noeuds : "+ nbrNoeuds);
			               labLiens.setText("Nombre de Liens : "+ nbrLiens);
		                if (tempsThreadGraphique == 0) //on met 2 points � l'origine du graphique et on instancie le temps actuel
		                {
		                	graphique.AjouterLien(0, 0);// � faire toutes les minutes ?
		                	graphique.AjouterNoeud(0, 0);// � faire toutes les minutes ?
		                	tempsThreadGraphique = System.currentTimeMillis();
		                }
		                else if (tempsActuel - tempsThreadGraphique >= 60000)//une minute �coul�e donc on affiche un nouveau point sur le graphique
		                {
		                	graphique.AjouterLien((int)(difference) / 60000, nbrLiens);
		                	graphique.AjouterNoeud((int)(difference) / 60000, nbrNoeuds);
		                	tempsThreadGraphique = System.currentTimeMillis();
		                	if (minuteRestant != 0)
		                	{
		                		minuteRestant--;
		                	}
		                	else
		                	{
		                		if(heureRestant > 0)
		                		{
		                			minuteRestant = 59;
		                			heureRestant--;
		                		}
		                	}
		                }
		                
		                heureEcoule = difference/(1000*60*60); //r�cup�re le nombre d'heures �coul�es
		                minuteEcoule = (difference/(1000*60))%60; //r�cup�re le nombre de minutes �coul�es modulo 60
		        	    
		                if (minuteEcoule >= 0 && minuteEcoule < 10)// il faut rajouter un 0
		                {
		                	labEcoule.setText("Temps �coul� : " + heureEcoule + "h0" + minuteEcoule);
		                }
		                else if(minuteEcoule >= 10 && minuteRestant <= 59) //tout est bon
		                {
		                	labEcoule.setText("Temps �coul� : " + heureEcoule + "h" + minuteEcoule);
		                }
		                else //minute sup�rieur � 60 pas possible
		                {
		                	labEcoule.setText("Temps �coul� : ");
		                }

		                	
		                if (minuteRestant >= 0 && minuteRestant < 10) //il faut rajouter un 0
		                {
		                	labRestant.setText("Temps restant : " + heureRestant + "h0" + minuteRestant);
		                }
		                else if(minuteRestant >= 10 && minuteRestant <= 59) //tout est bon
		                {
		                	labRestant.setText("Temps restant : " + heureRestant + "h" + minuteRestant);
		                }
		                else //minute sup�rieur � 60 pas possible
		                {
		                	labRestant.setText("Temps restant : ");			
		                }
		        		
		                progress.setProgress((double)(((double)difference/(1000*60))/(double)tempsTotalEstime));
		                
		                if((double)((double)difference/(1000*60)) >= tempsTotalEstime)
		                {
		                	graphique.AjouterLien((int)(difference) / 60000, nbrLiens);
		                	graphique.AjouterNoeud((int)(difference) / 60000, nbrNoeuds);
			                progress.setProgress(1);
		                	labRestant.setText("Temps restant : 0h00");
            				stopThread = true;  //arreter le crawler
            				//rajouter exportation du graphe au format graphml
		                }
					}
		        };
		               
		        while (true) { //boucle pour incr�menter les valeurs (cr�er des valeurs bidons)
		        	try {
		        		Thread.sleep(1000); //attendre pour ne pas faire trop d'update/incr�mentations, ce ne sont que des valeurs bidons !
		        		nbrUrl++;
		                nbrNoeuds *= 2;
		                if (nbrNoeuds > 1000)
		                {
		                	nbrNoeuds = 2;
		                }
		                nbrLiens++;
		             } catch (InterruptedException ex) {
		                System.out.println("Timer error");
		             }
		        	
	        		if (stopThread)
	        		{
	        			Thread.currentThread().interrupt();
	        			return;
	        		}
		                   
		              Platform.runLater(updater);//update les valeurs sur la GUI
		            }
		    }
		});
		
		thread.setDaemon(true);
		thread.start();
*/		
/*		primaryStage.setScene(scene);
		primaryStage.show();
*/				
//	}
	
//}


