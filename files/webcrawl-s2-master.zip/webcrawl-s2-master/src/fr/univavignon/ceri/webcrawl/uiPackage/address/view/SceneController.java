package fr.univavignon.ceri.webcrawl.uiPackage.address.view;



import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sun.glass.ui.Window;

import fr.univavignon.ceri.webcrawl.uiPackage.address.MainApp;
import fr.univavignon.ceri.webcrawl.uiPackage.address.model.LaunchSettings;
import fr.univavignon.ceri.webcrawl.uiPackage.address.model.Url;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.Node;

public class SceneController {

    private LaunchSettings settings; 
	
    private MainApp mainApp;
    
    @FXML
    private Button b1; 

    @FXML
    private Button b2; 
    
    @FXML
    private Button b3; 
    
    private boolean isActivated  = false; 
	
  
    public SceneController() {
    	
	
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
    	
    	
    }
    
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
        this.settings = mainApp.getSettings();
        
        //System.out.println("ici: " + settings);

        
    }

    /**
     * Is called by the main application to give a reference back to itself.
     * 
     * @param mainApp
     * @throws IOException 
     */

        
    
    @FXML
    public void switchToCible() 
    {
    	//showUrlOverview()
    	//System.out.println("test " + this.mainApp);
    	this.mainApp.showUrlOverview(); 
    	Pattern p = Pattern.compile("(@)?(href=')?(HREF=')?(HREF=\")?(href=\")?(http://)?(https://)?[a-zA-Z_0-9\\-]+(\\.\\w[a-zA-Z_0-9\\-]+)+(/[#&\\n\\-=?\\+\\%/\\.\\w]+)?"); 
    	b1.setDisable(true); 
    	b2.setDisable(false);
    	b3.setDisable(true);
    	if(settings.getUrlData().size() > 0)
        {
    		for (Url i : settings.getUrlData())
            {
            	
           	 //System.out.println("valeur: " + i.getUrl());
             Matcher m1 = p.matcher(i.getUrl()); 
           	
           	 boolean b = m1.matches();
           	 
           	 //System.out.println(b + " ");
           	 if(!b)
           		{
           		 
           		this.buttonDisable("b3");
           		break; 
           		}
           	 	this.buttonEnable("b3");
            	
            }
        }
        else
        {
        	this.buttonDisable("b3");
        }
    	//b1.setDisable(true); 
    	
    }
    
    @FXML
    public void switchToSettings()
    {
    	//System.out.println("test2 " + this.mainApp);
    	this.mainApp.showSettingsOverview();
    	b1.setDisable(false); 
    	b2.setDisable(true); 
    	b3.setDisable(true);
    	Pattern p = Pattern.compile("(@)?(href=')?(HREF=')?(HREF=\")?(href=\")?(http://)?(https://)?[a-zA-Z_0-9\\-]+(\\.\\w[a-zA-Z_0-9\\-]+)+(/[#&\\n\\-=?\\+\\%/\\.\\w]+)?"); 
    	if(settings.getUrlData().size() > 0)
        {
    		for (Url i : settings.getUrlData())
            {
            	
           	 //System.out.println("valeur: " + i.getUrl());
             Matcher m1 = p.matcher(i.getUrl()); 
           	
           	 boolean b = m1.matches();
           	 
           	 //System.out.println(b + " ");
           	 if(!b)
           		{
           		 
           		this.buttonDisable("b3");
           		break; 
           		}
           	 	this.buttonEnable("b3");
            	
            }
        }
        else
        {
        	this.buttonDisable("b3");
        }
    }
    
    @FXML
    public void switchToStart() throws Exception
    {
    	if(!isActivated)
    	{
    		
    	
    	//System.out.println("test3 " + this.mainApp);
    	this.mainApp.showLaunchOverview();
    	b1.setDisable(true); 
    	b2.setDisable(true); 
    	b3.setText("Arreter"); 
    	b3.setDisable(false);
    	isActivated = true; 
    	}
    	else
    	{
    		b1.setDisable(false); 
        	b2.setDisable(false); 
        	b2.setDisable(false);
    		b3.setText("Lancement");
    		isActivated = false;
    	}
    	
    }
    
    public void buttonDisable(String b)
    {
    	switch(b)
    	{
    		case "b1":
    			b1.setDisable(true);
    		case "b2":
    			b2.setDisable(true);
    		case "b3":
    			b3.setDisable(true);
    			
    	}
    }
    
    public void buttonEnable(String b)
    {
    	switch(b)
    	{
    		case "b1":
    			b1.setDisable(false);
    		case "b2":
    			b2.setDisable(false);
    		case "b3":
    			b3.setDisable(false);
    			
    	}
    }
    
	
}
