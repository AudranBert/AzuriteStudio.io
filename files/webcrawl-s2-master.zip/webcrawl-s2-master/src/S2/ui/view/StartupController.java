package S2.ui.view;


import S2.ui.MainApp;
import com.sun.glass.ui.CommonDialogs;
import fr.univavignon.ceri.webcrawl.GraphPackage.Graph;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

import java.io.File;

public class StartupController {
	
    private MainApp mainApp;
    public File f;

    @FXML
    private Text filename;

    @FXML
    private Button navigation;
	
	public StartupController() {
    	
		
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        navigation.setDisable(true);
    	
    	
    }
    
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
        
    }
    
    public void switchToResult() throws Exception
    {
        if (f!=null){
            System.out.println("ici");
            mainApp.showResultOverview();
        }
    	System.out.println("Pas de fichier");
    }

    public void selectFile(){       //file selector
        System.out.println("File selected");
        FileChooser fc=new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("GraphML files","*.graphml"));
        f=fc.showOpenDialog(null);
        if (f!=null){
            System.out.println(f.getAbsolutePath());
            Arguments.fileName=f.getAbsolutePath();     //store the fileName
            filename.setText("Fichier choisi: " + f.getName());
            navigation.setDisable(false);
        }
        else
        {
            navigation.setDisable(true);
        }

    }

}
