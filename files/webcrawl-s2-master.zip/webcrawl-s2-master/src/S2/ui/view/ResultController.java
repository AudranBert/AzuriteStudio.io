package S2.ui.view;


import S2.ui.GraphVisualisation.*;

import S2.ui.MainApp;

import S2.ui.GraphVisualisation.Graph;
import S2.ui.GraphVisualisation.Model;
import S2.ui.PageRank.PageRank;

import S2.ui.Stats.Stats;
import fr.univavignon.ceri.webcrawl.GraphPackage.Node;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javax.swing.*;
import java.util.ArrayList;

public class ResultController {

	@FXML
	private BorderPane root = new BorderPane();

	@FXML
    private Text firstRank;

	@FXML
    private Text lastRank;

	@FXML
    private Text globalTransitivityText;

	@FXML
    private Text reciprocityText;

	@FXML
    private Text assortativityText;

	@FXML
    private Text iterationFRText;

	@FXML
    private Text nodeNumberText;

	@FXML
    private Text edgeNumberText;

    @FXML
    private Text strongestCellText;

    @FXML
    private Button startButton;

    @FXML
    private Pane graphDisplay;

    @FXML
    private Button distant_local;

    @FXML
    private Button distant_degree_in;

    @FXML
    private Button distant_degree_out;

    @FXML
    private Button distant_degree_total;

    @FXML
    private Button distant_avg;

    private Stats stats;

	//on creer le graphe
	Graph graph = new Graph();
    fr.univavignon.ceri.webcrawl.GraphPackage.Graph graphMLResult=new fr.univavignon.ceri.webcrawl.GraphPackage.Graph();
    ArrayList<Double> ranks=new ArrayList<>();

    private MainApp mainApp;


	public ResultController() {

    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {

    }

    //on lance l'affichage du graphe dï¿½s que le bouton pour afficher cette fenï¿½tre est cliquï¿½.
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
        distant_local.setDisable(true);
        distant_degree_in.setDisable(true);
        distant_degree_out.setDisable(true);
        distant_degree_total.setDisable(true);
        distant_avg.setDisable(true);

    }

    @FXML
    public void start()
    {
        graphMLResult.readGraphml(Arguments.fileName);      //read the file
        //System.out.println(graph);
        //System.out.println(graph);
        PageRank pageRank=new PageRank();
        ranks=pageRank.calculateGraphRank(graphMLResult);   //calcul the rank


        System.out.println("\nStats :");
        stats = new Stats(graphMLResult);
        stats.degreeCalculation();//Degree calcul
        stats.transitivityCalculation();//Transitivity calcul
        for (Node node : graphMLResult.getlistNode())
        {
            stats.dijkstra(node);
        }
        stats.reciprocity();
        stats.assortativity();
        stats.maxDegree();

        ArrayList<Integer> totalDegrees = stats.getTotalDegreesTable();
        ArrayList<Integer> outDegrees = stats.getOutDegreesTable();
        ArrayList<Integer> inDegrees = stats.getInDegreesTable();
        float globalTransitivity = stats.getGlobalTransitivity();
        ArrayList<Float> localTransitivities = stats.getLocalTransitivityTable();
        ArrayList<Float> avgDistances = stats.getAvgDistanceTable();
        float reciprocity = stats.getReciprocity();
        float assortativity = stats.getAssortativity();
        int maxDegree = stats.getMaxDegree();
        Node nodeMaxDegree = stats.getNodeMaxDegree();

        globalTransitivityText.setText("Transitivite globale : " + globalTransitivity);
        reciprocityText.setText("Reciprocite : " + reciprocity);
        assortativityText.setText("Coefficient d'assortativite de degrees : " + assortativity);
        nodeNumberText.setText("Nombre de noeuds : " + graphMLResult.getlistNode().size());
        strongestCellText.setText("L'URL ayant le plus de \n" +
                "degres/force : " + nodeMaxDegree.getUrl());

        System.out.println("\nPrints : ");
        System.out.println("Total degrees for each node : " + totalDegrees);
        System.out.println("Out degrees for each node : " + outDegrees);
        System.out.println("In degrees for each node : " + inDegrees);
        System.out.println("Global transitivity : " + globalTransitivity);
        System.out.println("Local transitivity for each node : " + localTransitivities);
        System.out.println("Average distance to reach another node : " + avgDistances);
        System.out.println("Reciprocity : " + reciprocity);
        System.out.println("Assortativity : " + assortativity);
        System.out.println("Max degree : " + maxDegree);
        System.out.println("Node max degree : " + nodeMaxDegree.getId());

        //on met le graph au centre de la anchorpane
        graphDisplay.getChildren().add(graph.getDisplayPane());

        //on y ajoute le graphe
        addGraphComponents();
        edgeNumberText.setText("Nombre de liens : " + graph.getModel().getAllEdges().size());

        //on fait l'algo de disposition pour afficher (BasicLayout pour l'instant)
        //Layout layout = new BasicLayout(graph);
        Layout layout = new FruchtermanReingoldLayout(graph, graphDisplay);
        layout.execute();
        iterationFRText.setText("Nombre d'iterations : " + layout.getIteration());

        System.out.println("FIN");
        distant_local.setDisable(false);
        distant_degree_in.setDisable(false);
        distant_degree_out.setDisable(false);
        distant_degree_total.setDisable(false);
        distant_avg.setDisable(false);
        startButton.setDisable(true);
    }

    @FXML
    public void backToStartup() throws Exception
    {
    	this.mainApp.showStartupOverview();
    }

    @FXML
    public void goToDegreesEntrants()
    {
        final Stage primaryStage = new Stage();
        final Stage dialog = new Stage();
        XYChart.Series series = new XYChart.Series();

        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Degrees Entrants");
        yAxis.setLabel("Nombre de noeuds");
        LineChart<Number, Number> lineChart= new LineChart<Number, Number>(xAxis, yAxis);
        lineChart.setTitle("Degrees Entrants");

        int maxDegree = 0;
        for (int degree: stats.getInDegreesTable())
        {
            if (degree > maxDegree){
                maxDegree = degree;
            }
        }
        int[] degreeQuantity = new int[maxDegree+1];
        for (int i = 0; i < maxDegree+1; i++)
        {
            degreeQuantity[i] = 0;
        }
        for (int degree : stats.getInDegreesTable())
        {
            degreeQuantity[degree]++;
        }
        for (int i = 0; i < maxDegree+1; i++)
        {
            series.getData().add(new XYChart.Data(i, degreeQuantity[i]));
        }

        dialog.setResizable(false);

        dialog.setTitle("WebCrawler - Degrees Entrants");
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(primaryStage);
        VBox dialogVbox = new VBox(20);
        lineChart.getData().add(series);
        dialogVbox.getChildren().add(lineChart);
        Scene dialogScene = new Scene(dialogVbox, 800, 400);
        dialog.setScene(dialogScene);
        dialog.show();
    }

    @FXML
    public void goToDegreesSortantes()
    {
        final Stage primaryStage = new Stage();
        final Stage dialog = new Stage();
        XYChart.Series series = new XYChart.Series();

        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Out degrees");
        yAxis.setLabel("Number of nodes");
        LineChart<Number, Number> lineChart= new LineChart<Number, Number>(xAxis, yAxis);
        lineChart.setTitle("Out degrees");

        int maxDegree = 0;
        for (int degree: stats.getOutDegreesTable())
        {
            if (degree > maxDegree){
                maxDegree = degree;
            }
        }
        int[] degreeQuantity = new int[maxDegree+1];
        for (int i = 0; i < maxDegree+1; i++)
        {
            degreeQuantity[i] = 0;
        }
        for (int degree : stats.getOutDegreesTable())
        {
            degreeQuantity[degree]++;
        }
        for (int i = 0; i < maxDegree+1; i++)
        {
            series.getData().add(new XYChart.Data(i, degreeQuantity[i]));
        }

        dialog.setResizable(false);

        dialog.setTitle("WebCrawler - Degrees Sortants");
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(primaryStage);
        VBox dialogVbox = new VBox(20);
        lineChart.getData().add(series);
        dialogVbox.getChildren().add(lineChart);
        Scene dialogScene = new Scene(dialogVbox, 800, 400);
        dialog.setScene(dialogScene);
        dialog.show();
    }

    @FXML
    public void goToDegreesTotal()
    {
        final Stage primaryStage = new Stage();
        final Stage dialog = new Stage();
        XYChart.Series series = new XYChart.Series();

        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Total degrees");
        yAxis.setLabel("Number of nodes");
        LineChart<Number, Number> lineChart= new LineChart<Number, Number>(xAxis, yAxis);
        lineChart.setTitle("Total degrees");

        int maxDegree = 0;
        for (int degree: stats.getTotalDegreesTable())
        {
            if (degree > maxDegree){
                maxDegree = degree;
            }
        }
        int[] degreeQuantity = new int[maxDegree+1];
        for (int i = 0; i < maxDegree+1; i++)
        {
            degreeQuantity[i] = 0;
        }
        for (int degree : stats.getTotalDegreesTable())
        {
            degreeQuantity[degree]++;
        }
        for (int i = 0; i < maxDegree+1; i++)
        {
            series.getData().add(new XYChart.Data(i, degreeQuantity[i]));
        }

        dialog.setResizable(false);

        dialog.setTitle("WebCrawler - Degrees Totaux");
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(primaryStage);
        VBox dialogVbox = new VBox(20);
        lineChart.getData().add(series);
        dialogVbox.getChildren().add(lineChart);
        Scene dialogScene = new Scene(dialogVbox, 800, 400);
        dialog.setScene(dialogScene);
        dialog.show();
    }

    @FXML
    public void goToAvgDistances()
    {
        final Stage primaryStage = new Stage();
        final Stage dialog = new Stage();
        XYChart.Series series = new XYChart.Series();

        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Distance moyenne entre X et X+1");
        yAxis.setLabel("Nombre de noeuds");
        LineChart<Number, Number> lineChart= new LineChart<Number, Number>(xAxis, yAxis);
        lineChart.setTitle("Distance Moyenne");

        int maxDistance = 0;
        ArrayList<Float> avgDistances = stats.getAvgDistanceTable();
        while (avgDistances.remove(null))
        {

        }
        for (float distance: avgDistances)
        {
            int dist = (int) distance;
            if (distance > maxDistance){
                maxDistance = dist;
            }
        }
        maxDistance++;
        int[] distanceTable = new int[maxDistance];
        for (int i = 0; i < (int) maxDistance; i++)
        {
            distanceTable[i] = 0;
        }
        for (float distance : avgDistances)
        {
            int dist = (int) distance;
            distanceTable[dist]++;
        }
        for (int i = 0; i < distanceTable.length; i++)
        {
            series.getData().add(new XYChart.Data(i, distanceTable[i]));
        }

        dialog.setResizable(false);

        dialog.setTitle("WebCrawler - Distances Moyennes");
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(primaryStage);
        VBox dialogVbox = new VBox(20);
        lineChart.getData().add(series);
        dialogVbox.getChildren().add(lineChart);
        Scene dialogScene = new Scene(dialogVbox, 800, 400);
        dialog.setScene(dialogScene);
        dialog.show();
    }

    @FXML
    public void goToLocalTransitivity()
    {
        final Stage primaryStage = new Stage();
        final Stage dialog = new Stage();
        XYChart.Series series = new XYChart.Series();

        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Pourcentage de transitivite locale");
        yAxis.setLabel("Nombre de noeuds");
        LineChart<Number, Number> lineChart= new LineChart<Number, Number>(xAxis, yAxis);
        lineChart.setTitle("Transitivite Locale");

        int maxTransitivity = 0;
        ArrayList<Float> localTransitivities = stats.getLocalTransitivityTable();
        for (float localTransitivity: localTransitivities)
        {
            localTransitivity *= 100;
            int transitivity = (int) localTransitivity;
            if (transitivity > maxTransitivity){
                maxTransitivity = transitivity;
            }
        }
        if (maxTransitivity < 100)
        {
            maxTransitivity = 100;
        }
        int[] transitivityTable = new int[maxTransitivity+1];
        for (int i = 0; i <= (int) maxTransitivity; i++)
        {
            transitivityTable[i] = 0;
        }
        for (float localTransitivity : localTransitivities)
        {
            localTransitivity *= 100;
            int transitivity = (int) localTransitivity;
            transitivityTable[transitivity]++;
        }
        for (int i = 0; i < transitivityTable.length; i++)
        {
            series.getData().add(new XYChart.Data(i, transitivityTable[i]));
        }

        dialog.setResizable(false);

        dialog.setTitle("WebCrawler - Transitivite locale");
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(primaryStage);
        VBox dialogVbox = new VBox(20);
        lineChart.getData().add(series);
        dialogVbox.getChildren().add(lineChart);
        Scene dialogScene = new Scene(dialogVbox, 800, 400);
        dialog.setScene(dialogScene);
        dialog.show();
    }


    //mï¿½thode pour ajouter les noeuds et les arrï¿½tes.
    private void addGraphComponents()
	{

    	//on creer le modele (le contenant), ou sera stockï¿½ le graphe
		Model model = graph.getModel();

		int max=0;      //node with higher score
		int min=0;      //node with the lower score
        for (int i=0;i<graphMLResult.getlistNode().size();i++){     //all nodes
            model.addCell(graphMLResult.getlistNode().get(i).getUrl(),ranks.get(i));    //add the node
            if(ranks.get(max)<ranks.get(i)){    //check if it is the new max
                max=i;
            }
            if(ranks.get(min)>ranks.get(i)){    //check if it is the new min
                min=i;
            }
        }

        firstRank.setText("L'url classe premier : "+graphMLResult.getlistNode().get(max).getUrl());        //set the text rank score max
        lastRank.setText("L'url classe dernier : "+graphMLResult.getlistNode().get(min).getUrl());         //set the text rank score min


        for (int i=0;i<graphMLResult.getlistNode().size();i++){
            if(graphMLResult.getlistNode().get(i).getListEdge()!=null) {
                for (int j = 0; j < graphMLResult.getlistNode().get(i).getListEdge().size(); j++) {
                    //System.out.println(graphMLResult.getlistNode().get(i).getListEdge().get(j).getsrc() + "   " + graphMLResult.getlistNode().get(i).getListEdge().get(j).getdest());
                    model.addEdge(graphMLResult.getlistNode().get(i).getListEdge().get(j).getsrc(), graphMLResult.getlistNode().get(i).getListEdge().get(j).getdest());
                    //add edges to the graph which will be displayed
                }
            }
        }


        graph.endUpdate();
	}
}
