package S2.ui.view;

import java.io.File;

public class Arguments {
    public static String fileName;      //store the file name between the 2 scenes
}
