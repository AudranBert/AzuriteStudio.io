package S2.ui.GraphVisualisation;

import javafx.scene.Group;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

public class Graph {

    private Model model;

    private Group canvas;

    private Pane displayPane;
    
    private Pane p; 

    public Graph() {
        this.model = new Model();
        
        //We will arrange the vertices in a JavaFX pane
        p = new Pane();

        canvas = new Group();

        canvas.getChildren().add(p);

        displayPane = new BorderPane(canvas);

    }

    //To get the pane instance (to get the size by exemple)
    public Pane getDisplayPane() {
        return this.displayPane;
    }

    //To get the model
    public Model getModel() {
        return model;
    }

    //to update the display of the graph
    public void endUpdate() {

        // We add the vertices and the edges to the graph (in the model)
        p.getChildren().addAll(model.getAddedEdges());
        p.getChildren().addAll(model.getAddedCells());

        // We merge the modifications
        getModel().merge();

    }

    
}