package S2.ui.GraphVisualisation;

import javafx.scene.Group;
import javafx.scene.shape.Line;

//pour creer une arr�te
public class Edge extends Group {

    protected Cell source;
    protected Cell target;

    private Line line;
    
    public Edge(Cell source, Cell target) { // We state the source and target vertices
    	
        this.source = source; 
        this.target = target;

        source.addCellChild(target);  //we state which vertices is the target
        target.addCellParent(source); //and the source

        //then we create the line that link theses to vertices
        line = new Line();


        //we anchor the begining of the edge at theses X and Y coordinates (and try to be at the center of the circle-shaped vertice at the same time)
        line.startXProperty().bind( source.layoutXProperty().add(source.getBoundsInParent().getWidth() / 5.5));
        line.startYProperty().bind( source.layoutYProperty().add(source.getBoundsInParent().getHeight() / 4));

        //we anchor the end of the edge at theses X and Y coordinates (and try to be at the center of the circle-shaped vertice at the same time)
        line.endXProperty().bind( target.layoutXProperty().add( target.getBoundsInParent().getWidth() / 5.5));
        line.endYProperty().bind( target.layoutYProperty().add( target.getBoundsInParent().getHeight() / 4));
        
        //Then we add this edge to the model
        getChildren().add( line);

    }

    //to get the coordinates of end of the source edge
    public Cell getSource() {
        return source;
    }

    //to get the coordinates of end of the target edge
    public Cell getTarget() {
        return target;
    }

}