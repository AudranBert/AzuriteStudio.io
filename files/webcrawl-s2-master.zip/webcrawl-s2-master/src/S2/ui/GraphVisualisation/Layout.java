package S2.ui.GraphVisualisation;

//on peut creer plusieurs agencements en cr�ant diff�rentes classes
public abstract class Layout {

    public abstract void execute();

    //to return the number of iteration of the program
    public abstract int getIteration();

}