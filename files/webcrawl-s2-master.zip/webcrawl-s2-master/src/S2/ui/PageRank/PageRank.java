package S2.ui.PageRank;

import fr.univavignon.ceri.webcrawl.GraphPackage.EdgeException;
import fr.univavignon.ceri.webcrawl.GraphPackage.Graph;
import fr.univavignon.ceri.webcrawl.GraphPackage.Node;

import java.util.ArrayList;
import java.util.List;

public class PageRank {

    private Graph graph;                            //graph
    private ArrayList<ArrayList<Integer>> listIn;   //list of node that point a node i
    private ArrayList<ArrayList<Integer>> listOut;  //list of node that is pointed by a node i
    private ArrayList<Double> listRank;             //list of rank score




    private void initListIn(){      //fill the listIn
        if (listIn==null){
            listIn=new ArrayList<ArrayList<Integer>>();
        }
        for (int i=0;i<graph.getlistNode().size();i++) {        //create a ArrayList for each node
            ArrayList<Integer> tmp = new ArrayList<Integer>();
            listIn.add(tmp);
        }
        for (int i=0;i<graph.getlistNode().size();i++){         //for all nodes of the graph
            if (graph.getlistNode().get(i).getListEdge()!=null){
                for (int j=0;j<graph.getlistNode().get(i).getListEdge().size();j++){        //for all links of the node i
                    int src=i;      //id of the source
                    int dest=graph.getlistNode().get(i).getListEdge().get(j).getIdDest();   //id of the target
                    listIn.get(dest).add(src);      //add the node src to dest

                }
            }

        }
        System.out.println(listIn);
    }

    private void initListOut(){         //fill the listOut
        if (listOut==null){
            listOut=new ArrayList<ArrayList<Integer>>();
        }
        for (int i=0;i<graph.getlistNode().size();i++) {    //create a ArrayList for each node
            ArrayList<Integer> tmp = new ArrayList<Integer>();
            listOut.add(tmp);
        }
        for (int i=0;i<graph.getlistNode().size();i++){     //for all nodes of the graph
            if (graph.getlistNode().get(i).getListEdge()!=null) {
                for (int j = 0; j < graph.getlistNode().get(i).getListEdge().size(); j++) {    //for all links of the node j
                    int src = i;  //id of the source

                    //Node node = findNode(graph.getlistNode().get(i).getListEdge().get(j).getdest());
                    //int dest = graph.getlistNode().indexOf(node);
                    int dest=graph.getlistNode().get(i).getListEdge().get(j).getIdDest();   //id of the target
                    //System.out.println(dest + "--->" + src);
                    //for (int w = 0; w < graph.getlistNode().get(i).getListEdge().get(j).getweight(); w++) {     //add the node weight times
                        listOut.get(src).add(dest); //add the node
                    //}
                }
            }
        }
        System.out.println(listOut);
    }
    private Double calculARank(int u,double d){     //method which calculate the score of the node u
        double rank=0;      //score
        double win=0.0;     //Win
        double wout=0.0;    //Wout
        double sIn=0;
        double sip=0;
        double sOut=0;
        double sop=0;

        for (int i : listIn.get(u)){        //for each node that points on u
            sIn=listIn.get(u).size();       //the number of nodes that point on u
            sip=0;
            sOut=listOut.get(u).size();     //the number of nodes that are pointed by u
            sop=0;
            for (int j=0;j<listOut.get(i).size();j++){      //for each node that is pointed by i
                int n=listOut.get(i).get(j);                //the node pointed by i
                sip += (listIn.get(n).size());              //size of inlinks of n
                sop += (listOut.get(n).size());             //size of outlinks of n
               /* if(u==0){
                    System.out.println("");
                    System.out.println("IN "+(listIn.get(n).size()));
                    System.out.println("Out "+(listOut.get(n).size()));
                }
                */
            }
            if (sip!=0 ){       //divide by 0 is impossible
                win=sIn/sip;    //number of inlinks of u divided by number of inlinks of all nodes which are pointed by i
            }
            if (sop!=0 ){
                wout=sOut/sop;  //wout
            }
            rank+=(listRank.get(i)*win*wout);       //add to rank the multiplication of the rank of i by win et wout
            /*if(u==0){
                System.out.println("Predecesseur:"+i+" Rank "+listRank.get(i)+" Win "+ win+" Wout "+wout);
                System.out.println("SIn="+sIn+"  Sip="+sip);
                //System.out.println("Test="+listIn.get(i).size());
                System.out.println("Rank "+rank);
            }
             */
        }

        return ((1-d)+(d*rank));    //return the rank
    }


    public ArrayList<Double> calculateGraphRank(Graph graph){       //calculate the PageRank of a graph
        this.graph=graph;
        initListIn();       //init list of inlinks
        initListOut();      //init list of outlinks
        int iteration=graph.getlistNode().size()/2;    //number of iteration
        //iteration=2;
        double d=0.85;      //value of d
        ArrayList<Double> listRankTmp=new ArrayList<>();    //create a list which will store score during one iteration
        // if we don't make a Tmp list we influence the on going iteration
        if (listRank==null){
            listRank=new ArrayList<Double>();
        }
        for (int i=0;i<this.graph.getlistNode().size();i++){    //initialize scores
            double r= (1.0/ this.graph.getlistNode().size());   // 1/number of nodes
            listRank.add(r);                                    //add the score to ListRank
            listRankTmp.add(0.0);
        }
        //System.out.println(listRank);
        for (int i=0;i<iteration;i++){          //do iteration iteration
            for (int node=0;node<this.graph.getlistNode().size();node++){   //for each node
                listRankTmp.set(node,calculARank(node,d));      //calcul the score and store it in ListRankTmp
            }
            for (int j=0;j<listRankTmp.size();j++){         //transfer from ListRankTmp to ListRank
                double rank=listRankTmp.get(j);
                listRank.set(j,rank);
            }
            System.out.println("ITERATION :"+(i+1));
            System.out.println("Rang du premier noeud: "+listRank.get(0));
            System.out.println("Rang du dernier noeud: "+listRank.get(listRank.size()-1));
        }
        //System.out.println(listRank);

        System.out.println("ITERATION:"+iteration);
        for (int i=0;i<listRank.size();i++){
            System.out.println(graph.getlistNode().get(i).getId()+"="+listRank.get(i));
        }


        return listRank;            //return ListRank
    }

    public static void main(String[] args) {
        Graph graph=new Graph();
        System.out.println("DEB");
        graph.readGraphml("Graphs/test-DLPA.graphml");
        //System.out.println(graph);
        System.out.println("FIN");


        //System.out.println(graph);
        PageRank pageRank=new PageRank();
        pageRank.calculateGraphRank(graph);
    }

}
