package S2.ui;



import java.io.IOException;

import S2.ui.GraphVisualisation.Graph;
import S2.ui.view.ResultController;
import S2.ui.view.StartupController;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainApp extends Application {

	private Stage primaryStage;
    private BorderPane rootLayout;
    
    Graph graph = new Graph();
    
       
    public MainApp() {

	}
    
   
    //action au d�marrage
    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage; 
        this.primaryStage.setTitle("WebCrawler"); //nom de la fen�tre
        this.primaryStage.setResizable(false); //non redimensionnable

        initRootLayout(); //on creer la scene racine 

        showStartupOverview(); //on affiche la scene de d�marrage
    }
    
    /**
     * Initializes the root layout.
     */
    public void initRootLayout() {
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();
            
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //pour afficher la scene de d�marrage 
    public void showStartupOverview() throws Exception {
    	try {
            
            FXMLLoader loader = new FXMLLoader();
                       
            loader.setLocation(MainApp.class.getResource("view/StartupOverview.fxml"));
          
            AnchorPane overview = (AnchorPane) loader.load();       
           
            rootLayout.setCenter(overview);
            
            StartupController controller = loader.getController(); 
            controller.setMainApp(this);           
            
        } catch (IOException e) {
            e.printStackTrace();
        } 
    }
    
    
    
    //pour afficher la scene du r�sultat 
    public void showResultOverview() throws Exception {
        try {
            
            FXMLLoader loader = new FXMLLoader();
                       
            loader.setLocation(MainApp.class.getResource("view/ResultOverview.fxml"));
          
            AnchorPane overview = (AnchorPane) loader.load();       
           
            rootLayout.setCenter(overview);
            
            ResultController controller = loader.getController(); 
            controller.setMainApp(this);           
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
	/**
	 * Returns the main stage.
	 * @return
	 */
	public Stage getPrimaryStage() {
		return primaryStage;
		 
	}

    public static void main(String[] args) {
        launch(args);
    }
}
