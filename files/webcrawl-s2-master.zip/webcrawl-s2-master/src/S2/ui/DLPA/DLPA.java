package S2.ui.DLPA;

import fr.univavignon.ceri.webcrawl.GraphPackage.Edge;
import fr.univavignon.ceri.webcrawl.GraphPackage.Graph;
import fr.univavignon.ceri.webcrawl.GraphPackage.Node;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;

public class DLPA {

    private HashMap<Integer, Community> communityList= new HashMap<Integer, Community>();
    private Graph graph;
    private int maxIteration;
    //private HashMap<Node, Node> maxVoisin = new HashMap<Node, Node>();
    private ArrayList<Integer> shuffleNode = new ArrayList<>();
    private Random randomGenerator;

    public DLPA(int maxIteration, Graph graph)
    {
        this.maxIteration = maxIteration;
        this.graph = graph;
        //for(Node node : graph.getlistNode())
        //    maxVoisin.put(node, null);
    }

    private void initialisationNoeud()
    {
        for (int i=0;i<graph.getlistNode().size();i++) {         //for all nodes of the graph
            graph.getlistNode().get(i).setLabel(i);              //initialize the label
            shuffleNode.add(i);
        }
    }


    private void labelPropagation()
    {
        initialisationNoeud();
        int nbr = 0;
        boolean steadyState = false;
        Collections.shuffle(shuffleNode);

        while (nbr < maxIteration && !steadyState)
        {

            for (int i = 0; i < graph.getlistNode().size(); i++)
            {
                int str;
                int maxStr = 0;
                Node noeud = graph.getlistNode().get(shuffleNode.get(i));

                Node strongerNode = null;
                ArrayList<Node> neighborOfNode = new ArrayList<Node>();
                if(noeud.getListEdge()!=null)
                {
                    for (Edge edge : noeud.getListEdge()) {
                        neighborOfNode.add(graph.getlistNode().get(edge.getIdDest())); }
                    for (Edge edge : noeud.getListEdge()) {
                        String nodeString = edge.getsrc();
                        neighborOfNode.add(graph.searchNode(nodeString));
                    }
                }

                if(neighborOfNode.size()>1) {
                    for (Node node : neighborOfNode) {
                        if(node!=null){
                            str = node.getStrenght();

                            if (str > maxStr) {
                                maxStr = str;
                            }
                        }
                    }

                    for (int j=0; j>neighborOfNode.size();j++) {
                        if(neighborOfNode.get(j)!=null){
                            if (neighborOfNode.get(j).getStrenght() < maxStr) {
                                neighborOfNode.remove(neighborOfNode.get(j));
                            }
                        }
                    }


                }
                Node voisinMax;
                if (neighborOfNode.size()>0) {
                    voisinMax = getRandomElement(neighborOfNode);
                    if (voisinMax != null) {
                        if (voisinMax.getLabel() != noeud.getLabel()) {
                            graph.getlistNode().get(shuffleNode.get(i)).setHasChanged(true);
                        } else {
                            graph.getlistNode().get(shuffleNode.get(i)).setHasChanged(false);
                        }
                        noeud.setLabel(voisinMax.getLabel());
                    }
                }
            }
            nbr+=1;
            steadyState = true;
            for(Node node : graph.getlistNode())
            {
                if(node.getHasChanged() == true)
                {
                    steadyState = false;
                    break;
                }
            }
        }

    }

    private void nodeInCommunity()
    {
        Community com = new Community(0);
        int lab = 0;
        for(Node node :  graph.getlistNode())
        {
            if(lab!=node.getLabel())
            {
                if(communityList.containsKey(node.getLabel()))
                {
                    communityList.get(node.getLabel()).addNode(node);
                }
                com = new Community(node.getLabel());
                communityList.put(node.getLabel(),com);
            }
        }
    }

    private void showTruc()
    {
        communityList.forEach((k,v) -> System.out.println("key: "+k+" value:"+v.getNbrOfNode()));
    }

    public Node getRandomElement(ArrayList<Node> list)
    {
        int index = 0;
        randomGenerator = new Random();
        if(list.size()>0)
            index = randomGenerator.nextInt(list.size());

        return list.get(index);
    }


    public static void main(String[] args) {
        Graph graph = new Graph();
        graph.readGraphml("Graphs/test-DLPA.graphml");
        DLPA dlpa = new DLPA(100, graph);
        dlpa.labelPropagation();
        dlpa.nodeInCommunity();
        dlpa.showTruc();

    }
}
