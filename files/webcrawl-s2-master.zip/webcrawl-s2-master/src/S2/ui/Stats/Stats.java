package S2.ui.Stats;

import fr.univavignon.ceri.webcrawl.GraphPackage.Edge;
import fr.univavignon.ceri.webcrawl.GraphPackage.Graph;
import fr.univavignon.ceri.webcrawl.GraphPackage.Node;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.lang.Math;

public class Stats {
    private final Graph graph;
    private ArrayList<Node> listNode; // Node list
    private ArrayList<Integer> totalDegreesTable = new ArrayList<Integer>(); //node's total degrees table
    private ArrayList<Integer> outDegreesTable = new ArrayList<Integer>(); //node's out degrees table
    private ArrayList<Integer> inDegreesTable = new ArrayList<Integer>(); //node's in degrees table
    private float globalTransitivity; // graph's global tansitivity
    private ArrayList<Float> localTransitivityTable = new ArrayList<Float>(); // local transitivity table
    private int[][] distanceMatrix; // Distance Matrix starting from each node
    private int[][] fatherMatrix; // Father Matrix starting from each node
    private float reciprocity;
    private float[][] assortativityMatrix;
    private float assortativity;
    private ArrayList<Float> avgDistanceTable = new ArrayList<Float>();
    private int maxDegree;
    private Node nodeMaxDegree;

    public Stats(Graph graphCopy){
        graph = graphCopy;

        int nodeNumber = 0;
        listNode = graph.getlistNode();
        distanceMatrix = new int[listNode.size()][listNode.size()];
        fatherMatrix = new int[listNode.size()][listNode.size()];
        assortativityMatrix = new float[listNode.size()][listNode.size()];
        maxDegree = 0;
        nodeMaxDegree = null;

        for (Node node : listNode) //Matrix and tables initialisation.
        {
            totalDegreesTable.add(0);
            outDegreesTable.add(0);
            inDegreesTable.add(0);
            localTransitivityTable.add((float) 0.0);
            avgDistanceTable.add((float) 0.0);

            for(int k = 0; k < listNode.size(); k++)
            {
                distanceMatrix[node.getId()][k] = -1;
                fatherMatrix[node.getId()][k] = -1;
                assortativityMatrix[node.getId()][k] = -1;
            }

            nodeNumber++;
        }
    }

    public void degreeCalculation(){
        int nodeNumber = 0;
        int edgeNumber = 0;

        for (Node node : listNode) //for each node
        {
            edgeNumber = 0;
            if (node.getListEdge() != null) { //if the node has links
                for (Edge edge : node.getListEdge()) { //for each link
                    totalDegreesTable.set(nodeNumber, totalDegreesTable.get(nodeNumber) + 1); //total degree for the node incremented
                    outDegreesTable.set(nodeNumber, outDegreesTable.get(nodeNumber) + 1); //out degree for the node incremented

                    totalDegreesTable.set(edge.getIdDest(), totalDegreesTable.get(edge.getIdDest()) + 1); //total degree for the destination node incremented
                    inDegreesTable.set(edge.getIdDest(), inDegreesTable.get(edge.getIdDest()) + 1); //in degree for the destination node incremented

                    edgeNumber++;
                }
            }

            nodeNumber++;
        }
    }

    public void transitivityCalculation(){
        float tripleCounter = 0;
        float triangleCounter = 0;
        float neighboursCounter = 0;
        float localNeighbourTripletLink = 0;

        for (Node node : listNode) //for each node
        {
            System.out.println("node : " + node.getId());
            neighboursCounter = 0;
            localNeighbourTripletLink = 0;
            ArrayList<Integer> neighbourhood = new ArrayList<Integer>(); //neighbourhood of the node (for local transitivity)
            ArrayList<Edge> neighbourhoodEdge = new ArrayList<Edge>(); //neighbourhood of the node (for local transitivity)

            if (node.getListEdge() != null)
            {
                for (Edge edge : node.getListEdge()) // we add the neighbours (for local transitivity)
                {
                    if(!neighbourhood.contains(edge.getIdDest()) && node.getId() != edge.getIdDest()) { //if the neighbour is already visited (in case of double or more links) and the link is not on itself
                        neighboursCounter++; //neighbours number incremented
                        neighbourhood.add(edge.getIdDest()); //add the node to the neighbourhood
                        neighbourhoodEdge.add(edge); //add the edge to the edges to run
                    }
                }
                System.out.println("neighbourhood : " + neighbourhood);

                for (Edge edge : neighbourhoodEdge) //for each edge of the node
                {
                    if (node.getId() != edge.getIdDest()) //if the link is not going on himself
                    {
                        System.out.println("Neighbours : " + edge.getIdDest());
                        ArrayList<Integer> neighbourReached = new ArrayList<Integer>(); //neighbourhood of the node (for local transitivity)

                        if (listNode.get(edge.getIdDest()).getListEdge() != null) { //if destination node has links
                            for (Edge edge2 : listNode.get(edge.getIdDest()).getListEdge()) { //for each link of the second node
                                if (edge2.getIdDest() != node.getId() && edge2.getIdDest() != edge.getIdDest()) { //if the link's destination is not the first node or  the node himself
                                    System.out.println(node.getId() + " to " + edge.getIdDest() + " to " + edge2.getIdDest());

                                    //geometrical version of the transitivity
                                    //change the times (*) for a "+" for an arithmetic version of the transitivity
                                    tripleCounter += Math.sqrt(edge.getweight() * edge2.getweight()); //triplet incremented

                                    if (neighbourhood.contains(edge2.getIdDest()) && !neighbourReached.contains(edge2.getIdDest())) { //if the final destination is in the neighbourhood of the first node
                                        neighbourReached.add(edge2.getIdDest());
                                        localNeighbourTripletLink++; //local triplet incremented
                                    }

                                    if (listNode.get(edge2.getIdDest()).getListEdge() != null) { //if the 2nd node has links
                                        for (Edge edge3 : listNode.get(edge2.getIdDest()).getListEdge()) { //for each link of the third node
                                            if (edge3.getIdDest() == node.getId()) { //if the link's destination is the first node
                                                System.out.println(node.getId() + " to " + edge.getIdDest() + " to " + edge2.getIdDest() + " to " + edge3.getIdDest());

                                                //geometrical version of the transitivity
                                                //change the times (*) for a "+" for an arrithmetic version of the transitivity
                                                triangleCounter += Math.sqrt(edge.getweight() * edge2.getweight()); //triangle incremented
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            System.out.println("neighbours counter : " + neighboursCounter);
            System.out.println("local neighbourhood links : " + localNeighbourTripletLink);
            if(neighboursCounter > 1) //if the node has more than 1 neighbour
            {
                localTransitivityTable.set(node.getId(), localNeighbourTripletLink / (neighboursCounter * (neighboursCounter - 1))); //local transitivity calcul
            }
            else
            {
                localTransitivityTable.set(node.getId(), (float) 0); //the node has no neighbour. Local transitivity = 0
            }

            System.out.println();
        }

        System.out.println("triplet counter : " + tripleCounter);
        System.out.println("triangle counter : " + triangleCounter);

        if(tripleCounter != 0) //division by 0
        {
            globalTransitivity = triangleCounter/tripleCounter; //global transitivity calcul
        }
        else
        {
            globalTransitivity = 0; //global transitivity = 0
        }
    }

    public void dijkstra(Node node)
    {
        int[] distanceTable = new int[listNode.size()];
        ArrayList<Integer> C = new ArrayList<Integer>(); //list of nodes already checked
        ArrayList<Integer> CContrary = new ArrayList<Integer>(); //list of nodes to check
        int[] fatherTable = new int[listNode.size()];
        int[][] weights = new int[listNode.size()][listNode.size()]; //weights matrix

        for(int i = 0; i < listNode.size(); i++) //matrix filling
        {
            if (i != node.getId()) //every node except the one of the beginning
            {
                CContrary.add(1); // 1 as we need to check the node
                C.add(-1); // -1 as we haven't checked it yet
                distanceTable[i] = 999999; //high distance
                fatherTable[i] = -1; // no father yet
            }
            else //the node of the beginning of the algorithm
            {
                CContrary.add(-1); // -1 as we will check it first
                C.add(1); // 1 as we will check it first
                distanceTable[i] = 0; // 0 of distance
                fatherTable[i] = i; // his own father
            }

            for (int k = 0; k < listNode.size(); k++)
            {
                weights[i][k] = -1; //all weights are initialized at -1
            }
        }

        for (Node nodeParcours : listNode) // weight matrix initialization
        {
            if (nodeParcours.getListEdge() != null) {
                for (Edge edge : nodeParcours.getListEdge()) {
                    weights[nodeParcours.getId()][edge.getIdDest()] = edge.getweight();
                }
            }
        }

        int j = node.getId(); //j is the node we are checking

        for (int i = 0; i < listNode.size()-1; i++) //Dijkstra algorithm
        {
            int min = -1;

            for (int k = 0; k < listNode.size(); k++) //for all nodes
            {
                if (CContrary.get(k) == 1) //if the node is not yet checked
                {
                    if (j != k) //if the node is not the one we are currently checking
                    {
                        if(weights[j][k] != -1) //if there is a link between j and k
                        {
                            if(distanceTable[j] + weights[j][k] < distanceTable[k]) //if the distance to go to k from j is lower than the distance in the table
                            {
                                distanceTable[k] = distanceTable[j] + weights[j][k]; //we change the distance in the table
                                fatherTable[k] = j; //k's father is j
                            }
                        }

                        if (min == -1 || distanceTable[k] < distanceTable[min]) //if the distance to reach k is lower than the minimum found
                        {
                            min = k;
                        }
                    }
                }
            }

            j = min;
            CContrary.set(j, -1);
            C.set(j, 1);
        }

        for (int i = 0; i < listNode.size(); i++)
        {
            if(distanceTable[i] == 999999)
            {
                distanceTable[i] = -1;
            }
        }

/*        System.out.println("\nPeres : ");

        for (int i = 0; i < listNode.size(); i++)
        {
            System.out.println("Noeud " + i + " : " + fatherTable[i]);
        }

        System.out.println("\nDistances : ");

        for (int i = 0; i < listNode.size(); i++)
        {
            System.out.println("Noeud " + i + " : " + distanceTable[i]);
        }
*/
        distanceMatrix[node.getId()] = distanceTable;
        fatherMatrix[node.getId()] = fatherTable;

        //Average
        int reachable = 0;
        int distanceSum = 0;
        for (int i = 0; i < listNode.size(); i++)
        {
            if (distanceTable[i] != -1 && distanceTable[i] != 0)
            {
                reachable++;
                distanceSum += distanceTable[i];
            }
        }
        if (reachable != 0) {
            avgDistanceTable.set(node.getId(), (float) distanceSum / reachable);
        }
        else
        {
            avgDistanceTable.set(node.getId(), null);
        }
    }

    public void reciprocity(){
        float edgeCounter = 0;
        float reciprocityCounter = 0;

        for (Node node : listNode) //for each node
        {
            if(node.getListEdge() != null) //if the node has at least an edge
            {
                ArrayList<Integer> nodesReached = new ArrayList<Integer>(); //nodes Already reached

                for (Edge edge : node.getListEdge()) //for each edge
                {
                    if (node.getId() != edge.getIdDest() && !nodesReached.contains(edge.getIdDest())) //if the edge destination is not the node itself and the destination has not already been visited (in case of double or more links on a unique node)
                    {
                        nodesReached.add(edge.getIdDest()); //add the destination to the nodes visited
                        edgeCounter++;
                        if (listNode.get(edge.getIdDest()).getListEdge() != null) { //if the destination node has at least an edge
                            for (Edge edge2 : listNode.get(edge.getIdDest()).getListEdge()) { //for each edge
                                if(edge2.getIdDest() == node.getId()) //if the edge destination is the first node
                                {
                                    System.out.println("Source : " + node.getId() + " and Destination : " + edge.getIdDest());
                                    reciprocityCounter++; //recriprocity incremented
                                    break; //get out of the loop
                                }
                            }
                        }
                    }
                }
            }
        }

        System.out.println("Edge counter : " + edgeCounter);
        System.out.println("Reciprocity Counter : " + reciprocityCounter);
        if (edgeCounter != 0) { //division by 0
            reciprocity = reciprocityCounter / edgeCounter; //reciprocity calcul
        }
        else {
            reciprocity = 0;
        }
    }

    public void assortativity() {
        float totalAssortativity = 0; //addition of all node pairs assortativities

        for (Node node : listNode) { //for each node
            ArrayList<Edge> edgeList = node.getListEdge(); //list of edges of the first node

            for (Node node2 : listNode) //for each node
            {

                ArrayList<Integer> reached = new ArrayList<Integer>(); //List of nodes that has been already counted in the common degrees
                if (assortativityMatrix[node.getId()][node2.getId()] == -1 && node.getId() != node2.getId()) //if the assortativity for this pair of node is not made yet
                {
                    System.out.println("node paire : " + node.getId() + " and " + node2.getId());
                    ArrayList<Edge> edgeList2 = node2.getListEdge(); //list of edges of the 2nd node

                    float nodePairAssortativity = 0; //assortativity for this pair of node
                    int commonDegree = 0; //degrees in common for this pair of node
                    int uncommonDegree = 0; // degrees not in common for this pair of node

                    if(edgeList != null && edgeList2 != null) //if the edges lists are not null
                    {
                        for (Edge edge : edgeList) //for each edge of the first node
                        {
                            for (Edge edge2 : edgeList2) //for each edge of the second node
                            {
                                if (edge.getIdDest() == edge2.getIdDest()) //if the edges have the same destination
                                {
                                    if(!reached.contains(edge.getIdDest())) { //if this destination is not already counted as "in common"
                                        reached.add(edge.getIdDest()); //add this destination to the reached list
                                        commonDegree++; //common degree incremented
                                        break; //get out of the loop
                                    }
                                }
                            }
                        }
                        uncommonDegree = (edgeList.size() + edgeList2.size()) - commonDegree*2; //uncommon degree = both edges lists sizes minus the number of common degrees times 2
                    }


                    System.out.println("Common degrees : " + commonDegree);
                    System.out.println("Uncommon degrees : " + uncommonDegree);

                    if (edgeList != null) {
                        System.out.println("Number of edges : " + edgeList.size());
                    }

                    float probability = 0; //probability of having a link with the same destination
                    if (uncommonDegree != 0 || commonDegree != 0) {
                        probability = (float) commonDegree / (commonDegree + uncommonDegree);
                    }
                    System.out.println("Probability : " + probability);

                    nodePairAssortativity = (float) commonDegree * probability; //the assortativity for this node pair = number of degrees in common times the probability of having a link with the same destination
                    System.out.println("Assortativity for this pair : " + nodePairAssortativity);
                    totalAssortativity += nodePairAssortativity*2; //total assortativity of the graph incremented
                    System.out.println("Graph assortativity : " + totalAssortativity + "\n");

                    //assortativity for this pair of node is already calculated
                    assortativityMatrix[node.getId()][node2.getId()] = nodePairAssortativity;
                    assortativityMatrix[node2.getId()][node.getId()] = nodePairAssortativity;
                }
            }
        }

        assortativity = totalAssortativity/((listNode.size()*listNode.size())-listNode.size()); //total assortativity divided by the number of pairs minus the double pairs (for example node 10 and node 10)
        System.out.println("Assortativity : " + assortativity + "\n");
    }

    public void maxDegree(){
        if(totalDegreesTable.get(0) == 0)
        {
            degreeCalculation();
        }
        for (Node node : listNode)
        {
            if (totalDegreesTable.get(node.getId()) > maxDegree)
            {
                maxDegree = totalDegreesTable.get(node.getId());
                nodeMaxDegree = node;
            }
        }

        System.out.println("Max degree : " + maxDegree);
        System.out.println("Node with max degree : " + nodeMaxDegree.getId() + "\n");
    }

    public ArrayList<Integer> getTotalDegreesTable()
    {
        return totalDegreesTable;
    }

    public ArrayList<Integer> getOutDegreesTable()
    {
        return outDegreesTable;
    }

    public ArrayList<Integer> getInDegreesTable()
    {
        return inDegreesTable;
    }

    public float getGlobalTransitivity()
    {
        return globalTransitivity;
    }

    public ArrayList<Float> getLocalTransitivityTable()
    {
        return localTransitivityTable;
    }

    public int[][] getDistanceMatrix() {
        return distanceMatrix;
    }

    public int[][] getFatherMatrix() {
        return fatherMatrix;
    }

    public float getReciprocity() {
        return reciprocity;
    }

    public ArrayList<Float> getAvgDistanceTable() {
        return avgDistanceTable;
    }

    public float getAssortativity() {
        return assortativity;
    }

    public int getMaxDegree(){
        return maxDegree;
    }

    public Node getNodeMaxDegree(){
        return nodeMaxDegree;
    }

}
