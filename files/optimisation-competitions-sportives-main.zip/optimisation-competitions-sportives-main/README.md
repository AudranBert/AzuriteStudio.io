# Optimisation Compétitions Sportives

par Guillaume Bonenfant, Audran Bert et Ludovic Deloffre

## Installation

Nous avons utilisé Intellij Idea. SDK du projet: OpenJDK 17.0.2 
Pour installer les librairies : 
* JavaFX: via Maven (le pom.xml est dans le projet)
* Cplex: télécharger puis installer Cplex. Puis ajouter une librairie au projet et pointer sur "cplex/lib/cplex.jar" 
* Json (20220320): télécharger et ajouter au projet
* Sqlite (3.36.0.3): télécharger et ajouter au projet 
