package fr.univavignon.ceri.webcrawl;

/**
 * This class is used to launch the game.
 * 
 * @author Author 1
 * @author Author 2
 * @author Author 3
 * @author Author 4
 */
public class Launcher
{	
	
}
