package fr.univavignon.ceri.webcrawl.uiPackage.address.view;





import java.io.IOException;

import com.sun.glass.ui.Window;

import fr.univavignon.ceri.webcrawl.uiPackage.address.MainApp;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Spinner;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.Node;

public class GraphController {

    
    //private MainApp mainApp;
    
    private Stage GraphStage;
    
    /*@FXML
    private */ 
    
    public GraphController() {
    	
	    
    	
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
    	
                
    	
    }
    
    /**
     *
     * @param dialogStage
     */
    public void setDialogStage(Stage GraphStage) {
        this.GraphStage = GraphStage;
    }
    
   /*public void setMainApp(MainApp mainApp) {
    	//System.out.println(mainApp);
        //this.mainApp = mainApp;
        
        SceneController sceneC = this.mainApp.getSceneController(); 
        //if(this.mainApp.getUrlData().size() > 0)
        {
        	sceneC.buttonEnable("b3");
        	
        }
        else
        {
        	sceneC.buttonDisable("b3");
        	
        }
        //System.out.println(this.mainApp);

        
    } */

    

        
    
    
    
    
    
    
    
	
}