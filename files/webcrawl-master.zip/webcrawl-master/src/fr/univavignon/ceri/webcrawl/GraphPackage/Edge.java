package fr.univavignon.ceri.webcrawl.GraphPackage;


/**
 * @author audran
 * Edge class
 */
public class Edge {
	private String src;
	private int weight;
	private String dest;
	
	/**
	 * constructeur
	 * @param src
	 * @param poids
	 * @param dest
	 */
	public Edge(String src, int poids, String dest) {
		this.src = src;
		this.weight = poids;
		this.dest = dest;
	}


	/**
	 *ToString
	 *@return String
	 */
	@Override
	public String toString() {
		return "Lien [src=" + src + ", poids=" + weight + ", dest=" + dest + "]";
	}
	
	
	/**
	 * getsrc
	 * @return this.src
	 */
	public String getsrc() {
		return this.src;
	}
	
	/**
	 * getdest
	 * @return this.dest
	 */
	public String getdest() {
		return this.dest;
	}
	
	/**
	 * getweight
	 * @return this.weight
	 */
	public int getweight() {
		return this.weight;
	}
	
	/**
	 * setweight
	 * @param p
	 * @return boolean
	 */
	public boolean setweight(int p) {
		if (p<=0) {
			return false;
		}
		this.weight=p;
		return true;
	}
}
