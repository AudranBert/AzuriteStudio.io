package fr.univavignon.ceri.webcrawl.ParserPackage;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import javax.swing.plaf.synth.SynthOptionPaneUI;

import fr.univavignon.ceri.webcrawl.GraphPackage.Graph;

import java.util.ArrayList;
import java.util.HashMap;

public class ThreadLinkParserManager {
	private static int ctURLFound=0;				//nombre d'URL trouv� en parsant
	private static long lStartTime=0;				//temps au depart
	private static int ctURLParsed=0;					//nombre d'url qui ont �t� pars�
	
	
	public static int getCtURLFound() {
		return ctURLFound;
	}

	public static long getlStartTime() {
		return lStartTime;
	}

	public static int getCtURLParsed() {
		return ctURLParsed;
	}

	public static void displayListThread(ArrayList<ThreadLinkParser> l) {
		System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxx");
		for (int i=0;i<l.size();i++) {
			System.out.println("Resultat : "+ l.get(i).getLink()+" : "+l.get(i).getList().size()  );
		}
		System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxx");
	}
	
	public static void crawlerExec(ArrayList<URL> listSrc,int nbThreadSimultinus, int hauteurMax, int timeMax , boolean domainGraph, boolean stayOnDomain, boolean robotBool, boolean sitemapBool) throws Exception{
		Graph graphLink=new Graph(domainGraph);
		int nbMax = 0;
		if (hauteurMax==0) {
			hauteurMax=-1;
		}
		int nb=0;
		ctURLFound=0;
		int ctThread=0;
		ctURLParsed=0;
		lStartTime = System.currentTimeMillis();											//temps au lancement du parser
		ArrayList<ThreadLinkParser> listResThread = new ArrayList<ThreadLinkParser>();		//Liste contenant les objets pour conserver les resultats du parser
		ArrayList<Thread> listThread = new ArrayList<Thread>();								//liste contenant les threads en cours a l instant t
		ArrayList<LinkParser> listLinkParserToParse=new ArrayList<LinkParser>();
		int nbThreadExec=0;																	//compte le nombre de thread en cours d'execution
		for (int i=0;i<listSrc.size();i++) {
			//System.out.println(i);
			if (domainGraph) {
				LinkParser l=new LinkParser(listSrc.get(i),stayOnDomain,"Domaine",hauteurMax,null, new HashMap<URL, RobotsTxt>(), robotBool, sitemapBool);
				listLinkParserToParse.add(l);
			}
			else {
				LinkParser l=new LinkParser(listSrc.get(i),stayOnDomain,"Page",hauteurMax,null, new HashMap<URL, RobotsTxt>(), robotBool, sitemapBool);
				listLinkParserToParse.add(l);
			}

		}
		for (int i=0;i<listLinkParserToParse.size();i++) {												//cree NbThreadSimultinus si c'est possible ou sinon cree ListSrc.size() thread
			if ((nbThreadSimultinus>nbThreadExec) && ((ctThread<nbMax)|| (nbMax==0))) {
				ThreadLinkParser r = new ThreadLinkParser(listLinkParserToParse.get(ctThread));			//cree l objet ayant la fonction du thread
				Thread th=new Thread(r);														//cree un nouveau thread
				th.start();																		//lance le thread
				listResThread.add(r);															//ajoute l objet a la liste pour pouvoir recuperer les resultats			
				listThread.add(th);																//ajoute le thread a la liste des thread en cours
				nbThreadExec+=1;	
				if (listLinkParserToParse.get(ctThread).getHauteur()!=0) {
					ctURLParsed+=1;
				}
				ctThread+=1;	//ajoute un au nombre de thread en cours	

			}
		}
		while ((nbThreadExec!=0) &&  ((System.currentTimeMillis()-lStartTime<timeMax*1000)||(timeMax==0))){				//tant qu il y a des pages a parser (tant qu il a des threads en cours)
			for(int i=0;i<listThread.size();i++)
			{
				if (!(listThread.get(i).isAlive())) {											//regarde si le thread est fini
					//System.out.println("THREAD Termine : "+listResThread.get(nb).getLink() );
					nbThreadExec-=1;															//enleve un au nombre de thread en cours 
					listThread.remove(i);														//enleve le thread fini de la liste des threads en cours
					int timer=1;
					graphLink.addNode(listResThread.get(nb));
					while (listResThread.get(nb).getList().size()==0) {							//attend l'actualisation de la liste de lien du thread
						TimeUnit.MILLISECONDS.sleep(60);
						timer+=1;
						if (timer>=15) {
							break;
						}
					}
					if (listResThread.get(nb).getListLinkParser()!=null) {
						for (int j=0;j<listResThread.get(nb).getListLinkParser().size();j++) {
							//String txt=listResThread.get(nb).getListLinkParser().get(j).getURL().toString();
							if(listResThread.get(nb).getListLinkParser().get(j).getHauteur()!=0)
							{
								listLinkParserToParse.add(listResThread.get(nb).getListLinkParser().get(j));
							}
							/*if (!(listSrc.contains(new URL(txt)))) {						//regarde si le lien a d�j� �t� trait�
								listSrc.add(new URL(txt));
							}*/
							//System.out.println("Ajout de : "+listResThread.get(nb).getList().get(j).toString() );
						}
						ctURLFound+=listResThread.get(nb).getListLinkParser().size();							//ajoute le nombre d url trouv�
					}
					
					nb+=1;																		//compteur de l emplacment dans ListResThread
					if ((ctThread<listLinkParserToParse.size()) && ((ctThread<nbMax)|| (nbMax==0))) {			//si il reste des liens
						
						if (listLinkParserToParse.get(ctThread).getHauteur()!=0) {
							ctURLParsed+=1;
						}
						ThreadLinkParser r = new ThreadLinkParser(listLinkParserToParse.get(ctThread));		//creation nouveau thread pour remplacer celui qui est fini
						Thread th=new Thread(r);
						th.start();
						listResThread.add(r);
						listThread.add(th);
						ctThread+=1;
						nbThreadExec+=1;
					}
				}
			}
		}	
		long lEndTime = System.currentTimeMillis();
		//displayListThread(listResThread);
		long output = lEndTime - lStartTime;
		System.out.println("Elapsed time in seconds: " + output/1000);			//calcul temps total du parser
		System.out.println("Nombre de lien parse : "+ctURLParsed);
		System.out.println("Nombre de lien trouve : "+ctURLFound);
		graphLink.exportToGraphml();
	}
	
	public static void main(String[] args) throws Exception {								//UI = a lier a l interface graphique
		ArrayList<URL> listSrc = new ArrayList<URL>();								//liste page source pour parser UI
		listSrc.add(new URL("https://www.google.com"));
		listSrc.add(new URL ("https://trashtalk.com"));
		for (int i=0;i<listSrc.size();i++) {
			System.out.println("Lien "+i+" : "+listSrc.get(i));
		}
		System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxx");
		int nbThreadSimultinus=10;															//nombre maximale de processus simultane UI
		int maxSearch=1;
		int timeMax=60;
		boolean domain=false;
		boolean robot = false;
		boolean stayOn=false;
        boolean sitemap = false;
        crawlerExec(listSrc,nbThreadSimultinus,maxSearch,timeMax,domain, stayOn, robot, sitemap);
		
	}
	
}
